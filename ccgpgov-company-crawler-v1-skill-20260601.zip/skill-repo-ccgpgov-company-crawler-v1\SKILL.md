---
name: ccgpgov-company-crawler-v1
description: Use when Codex needs to search China Government Procurement notices for one company or keyword, extract notices from the last year, and export one Excel file. Trigger for requests like crawling procurement announcements, checking bid-winning records, or collecting government procurement hits for a single company name.
---

# CCGP Gov Company Crawler v1

## Overview

Run the bundled crawler when the task is: one keyword in, one Excel file out.

The skill already includes session warm-up, title search, full-text search, detail-page parsing, and Excel export.

## Quick Start

1. Install dependencies:

```bash
pip install -r "<skill-dir>/requirements.txt"
```

2. Change to the directory where the Excel file should be written.

3. Run:

```bash
python "<skill-dir>/scripts/run_crawler.py" "公司名称"
```

## Parameters

- `keyword`: required company name or keyword
- `--output-dir`: optional output directory, defaults to the current working directory
- `--days`: optional lookback window, defaults to `365`
- `--max-pages`: optional page cap per search type; by default the crawler reads the first page result count and auto-fetches all pages

Example:

```bash
python "<skill-dir>/scripts/run_crawler.py" "杭州安信检测技术有限公司" --max-pages 5
```

## Output

The runner writes one Excel file to the current working directory by default:

`<关键词>_近一年采购公告汇总_<YYYYMMDD>.xlsx`

Columns include keyword, notice type, title, published date, purchaser, agency, region, winner, amount, source URL, hit mode, and summary.

Pagination is automatic by default:

- search title first, then full text
- read page 1 result count like `共找到 66 条内容`
- calculate total pages by 20 rows per page
- fetch all pages unless `--max-pages` is explicitly provided

## Failure Mode

- If the site returns an anti-bot page, stop and report the error instead of producing an empty Excel file.
- If the site HTML changes, update the bundled parser files inside `scripts/ccgpgov_crawler/`.
