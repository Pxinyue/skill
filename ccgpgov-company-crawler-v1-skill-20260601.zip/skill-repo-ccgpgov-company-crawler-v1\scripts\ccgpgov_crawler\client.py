import random
import time
from datetime import date, timedelta
from typing import Optional

import requests

from ccgpgov_crawler.errors import AccessBlockedError


HOME_URL = "https://search.ccgp.gov.cn/"
SEARCH_URL = "https://search.ccgp.gov.cn/bxsearch"
DEFAULT_HEADERS = {
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
    "Accept-Encoding": "gzip, deflate, br, zstd",
    "Accept-Language": "zh-CN,zh;q=0.9",
    "Connection": "keep-alive",
    "DNT": "1",
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Sec-Fetch-User": "?1",
    "Upgrade-Insecure-Requests": "1",
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/145.0.0.0 Safari/537.36"
    ),
    "sec-ch-ua": '"Not:A-Brand";v="99", "Google Chrome";v="145", "Chromium";v="145"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"',
}


def build_search_params(keyword: str, search_type: int, page_index: int, days: int = 365) -> dict:
    end_date = date.today()
    start_date = end_date - timedelta(days=days)

    return {
        "searchtype": search_type,
        "page_index": page_index,
        "bidSort": 0,
        "buyerName": "",
        "projectId": "",
        "pinMu": 0,
        "bidType": 0,
        "dbselect": "bidx",
        "kw": keyword,
        "start_time": start_date.strftime("%Y:%m:%d"),
        "end_time": end_date.strftime("%Y:%m:%d"),
        "timeType": 6,
        "displayZone": "",
        "zoneId": "",
        "pppStatus": 0,
        "agentName": "",
    }


def is_access_blocked_html(html: str) -> bool:
    return "频繁访问!中国政府采购网" in html or "您的访问过于频繁" in html


class CCGPSearchClient:
    def __init__(
        self,
        session: Optional[requests.Session] = None,
        timeout: int = 15,
        min_delay_seconds: float = 1.0,
        max_delay_seconds: float = 5.0,
        blocked_retry_delay_range: tuple = (6.0, 10.0),
        max_blocked_retries: int = 2,
    ):
        self.session = session or requests.Session()
        self.timeout = timeout
        self.min_delay_seconds = min_delay_seconds
        self.max_delay_seconds = max_delay_seconds
        self.blocked_retry_delay_range = blocked_retry_delay_range
        self.max_blocked_retries = max_blocked_retries
        self._warmed_up = False
        self.session.headers.update(DEFAULT_HEADERS)

    def _sleep_short(self):
        time.sleep(random.uniform(self.min_delay_seconds, self.max_delay_seconds))

    def _sleep_after_block(self, attempt: int):
        del attempt
        time.sleep(random.uniform(*self.blocked_retry_delay_range))

    def _request_html(self, url: str, params: Optional[dict] = None) -> str:
        last_error = None
        max_attempts = self.max_blocked_retries + 1

        for attempt in range(1, max_attempts + 1):
            self._sleep_short()
            try:
                response = self.session.get(url, params=params, timeout=self.timeout)
                response.raise_for_status()
            except requests.RequestException as exc:
                last_error = exc
                if attempt == max_attempts:
                    raise
                self._sleep_after_block(attempt)
                continue

            response.encoding = response.apparent_encoding or response.encoding
            html = response.text
            if is_access_blocked_html(html):
                last_error = AccessBlockedError("中国政府采购网返回了反爬限制页面，请稍后重试或更换网络环境。")
                if attempt == max_attempts:
                    raise last_error
                self._sleep_after_block(attempt)
                continue

            return html

        if last_error:
            raise last_error
        raise AccessBlockedError("中国政府采购网返回了反爬限制页面，请稍后重试或更换网络环境。")

    def warm_up(self, keyword: str):
        if self._warmed_up:
            return

        self._request_html(HOME_URL)
        probe_params = build_search_params(keyword=keyword, search_type=1, page_index=1)
        self._request_html(SEARCH_URL, params=probe_params)
        self._warmed_up = True

    def fetch_search_page(self, keyword: str, search_type: int, page_index: int, days: int = 365) -> str:
        if not self._warmed_up:
            self.warm_up(keyword)

        return self._request_html(
            SEARCH_URL,
            params=build_search_params(keyword=keyword, search_type=search_type, page_index=page_index, days=days),
        )

    def fetch_detail_page(self, url: str) -> str:
        return self._request_html(url)
