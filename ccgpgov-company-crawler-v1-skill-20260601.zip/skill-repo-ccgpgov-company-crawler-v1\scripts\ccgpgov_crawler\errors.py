class CCGPCrawlerError(Exception):
    """Base error for crawler failures."""


class AccessBlockedError(CCGPCrawlerError):
    """Raised when the target site returns an anti-bot or access limit page."""
