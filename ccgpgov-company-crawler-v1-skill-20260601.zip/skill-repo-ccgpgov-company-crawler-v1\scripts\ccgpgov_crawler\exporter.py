from pathlib import Path
from typing import Iterable, Mapping

from openpyxl import Workbook


EXPORT_COLUMNS = [
    "keyword",
    "notice_type",
    "title",
    "published_at",
    "purchaser",
    "agency",
    "region",
    "budget_amount",
    "amount",
    "winner",
    "project_name",
    "url",
    "hit_mode",
    "summary",
]


def export_to_excel(records: Iterable[Mapping[str, str]], output_path: Path) -> Path:
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "采购公告"
    sheet.append(EXPORT_COLUMNS)

    for record in records:
        sheet.append([record.get(column, "") for column in EXPORT_COLUMNS])

    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    workbook.save(output)
    return output
