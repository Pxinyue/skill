from typing import Dict, Iterable, List


def merge_search_hits(title_hits: Iterable[Dict[str, str]], full_hits: Iterable[Dict[str, str]]) -> List[Dict[str, str]]:
    merged: Dict[str, Dict[str, str]] = {}

    for hit in list(title_hits) + list(full_hits):
        dedupe_key = hit.get("url") or f"{hit.get('title', '')}|{hit.get('published_at', '')}"
        if dedupe_key not in merged:
            merged[dedupe_key] = dict(hit)
            continue

        current_mode = merged[dedupe_key].get("hit_mode", "")
        new_mode = hit.get("hit_mode", "")
        if current_mode != new_mode:
            merged[dedupe_key]["hit_mode"] = "title+full_text"

    return list(merged.values())
