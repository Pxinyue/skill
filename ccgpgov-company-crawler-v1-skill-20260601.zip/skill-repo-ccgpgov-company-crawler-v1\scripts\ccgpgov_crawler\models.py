from dataclasses import dataclass


@dataclass
class NoticeRecord:
    keyword: str
    title: str
    notice_type: str
