import re
from typing import Dict, List, Optional

from bs4 import BeautifulSoup

from ccgpgov_crawler.errors import AccessBlockedError


DATE_PATTERN = re.compile(r"\d{4}-\d{2}-\d{2}")
SEARCH_DATE_PATTERN = re.compile(r"(\d{4})[.-](\d{2})[.-](\d{2})")
TOTAL_RESULTS_PATTERN = re.compile(r"共找到\s*(\d+)\s*条内容")
REGIONS = (
    "北京",
    "天津",
    "上海",
    "重庆",
    "河北",
    "山西",
    "内蒙古",
    "辽宁",
    "吉林",
    "黑龙江",
    "江苏",
    "浙江",
    "安徽",
    "福建",
    "江西",
    "山东",
    "河南",
    "湖北",
    "湖南",
    "广东",
    "广西",
    "海南",
    "四川",
    "贵州",
    "云南",
    "西藏",
    "陕西",
    "甘肃",
    "青海",
    "宁夏",
    "新疆",
)
FIELD_PATTERNS = {
    "project_name": [r"项目名称[:：]\s*(.+)"],
    "purchaser": [r"采购人[:：]\s*(.+)"],
    "agency": [r"代理机构[:：]\s*(.+)"],
    "winner": [r"供应商名称[:：]\s*(.+)", r"中标供应商[:：]\s*(.+)"],
    "amount": [r"中标(?:（成交）)?金额[:：]\s*([0-9.,]+\s*[万元亿元元]+)", r"成交金额[:：]\s*([0-9.,]+\s*[万元亿元元]+)"],
    "budget_amount": [r"预算金额[:：]\s*([0-9.,]+\s*[万元亿元元]+)"],
}


def _normalize_search_date(text: str) -> str:
    match = SEARCH_DATE_PATTERN.search(text)
    if not match:
        return ""
    return f"{match.group(1)}-{match.group(2)}-{match.group(3)}"


def _extract_search_meta_segments(item) -> List[str]:
    segments: List[str] = []
    for span in item.find_all("span"):
        span_text = span.get_text(" | ", strip=True)
        segments.extend(segment.strip() for segment in span_text.split("|") if segment.strip())
    return segments


def parse_total_results_count(html: str) -> Optional[int]:
    text = BeautifulSoup(html, "html.parser").get_text(" ", strip=True)
    match = TOTAL_RESULTS_PATTERN.search(text)
    if not match:
        return None
    return int(match.group(1))


def parse_search_results(html: str, hit_mode: str) -> List[Dict[str, str]]:
    soup = BeautifulSoup(html, "html.parser")
    title = soup.title.get_text(" ", strip=True) if soup.title else ""
    body_text = soup.get_text(" ", strip=True)
    if "频繁访问" in title or "访问过于频繁" in body_text:
        raise AccessBlockedError("中国政府采购网返回了反爬限制页面，请稍后重试或更换网络环境。")

    records: List[Dict[str, str]] = []

    for item in soup.select("ul.vT-srch-result-list-bid li"):
        anchor = item.find("a", href=True)
        if not anchor:
            continue

        segments = _extract_search_meta_segments(item)
        published_at = ""
        purchaser = ""
        agency = ""
        notice_type = ""
        region = ""

        for segment in segments:
            normalized_date = _normalize_search_date(segment)
            if normalized_date:
                published_at = normalized_date
            elif segment.startswith("采购人："):
                purchaser = segment.split("：", 1)[1].strip()
            elif segment.startswith("代理机构："):
                agency = segment.split("：", 1)[1].strip()
            elif segment in {"招标公告", "中标公告", "成交公告"}:
                notice_type = segment
            elif segment in REGIONS:
                region = segment

        if not notice_type:
            title_text = anchor.get_text(" ", strip=True)
            for candidate in ("招标公告", "中标公告", "成交公告"):
                if candidate in title_text:
                    notice_type = candidate
                    break

        records.append(
            {
                "title": anchor.get_text(" ", strip=True),
                "url": anchor["href"],
                "published_at": published_at,
                "purchaser": purchaser,
                "agency": agency,
                "notice_type": notice_type,
                "region": region,
                "hit_mode": hit_mode,
                "summary": item.get_text(" ", strip=True),
            }
        )

    return records


def parse_detail_page(html: str, url: str) -> Dict[str, str]:
    soup = BeautifulSoup(html, "html.parser")
    body_text = soup.get_text("\n", strip=True)

    detail = {
        "title": "",
        "notice_type": "",
        "published_at": "",
        "region": "",
        "project_name": "",
        "purchaser": "",
        "agency": "",
        "winner": "",
        "amount": "",
        "budget_amount": "",
        "content": body_text,
        "url": url,
    }

    title_node = soup.find(["h1", "title"])
    if title_node:
        detail["title"] = title_node.get_text(" ", strip=True)
        if "招标公告" in detail["title"]:
            detail["notice_type"] = "招标公告"
        elif "中标公告" in detail["title"]:
            detail["notice_type"] = "中标公告"
        elif "成交公告" in detail["title"]:
            detail["notice_type"] = "成交公告"

    date_match = DATE_PATTERN.search(body_text)
    if date_match:
        detail["published_at"] = date_match.group(0)

    for region in REGIONS:
        if region in body_text:
            detail["region"] = region
            break

    for field_name, patterns in FIELD_PATTERNS.items():
        for pattern in patterns:
            match = re.search(pattern, body_text)
            if match:
                detail[field_name] = match.group(1).strip()
                break

    return detail
