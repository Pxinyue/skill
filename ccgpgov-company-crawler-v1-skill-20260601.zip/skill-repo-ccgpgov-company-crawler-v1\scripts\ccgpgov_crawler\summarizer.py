from typing import Dict, Iterable, Tuple


def _collect_parts(record: Dict[str, str], fields: Iterable[Tuple[str, str]]) -> str:
    parts = []
    for label, key in fields:
        value = str(record.get(key, "")).strip()
        if value:
            parts.append(f"{label}：{value}")
    return "；".join(parts)


def build_summary(record: Dict[str, str]) -> str:
    notice_type = record.get("notice_type", "")
    if notice_type == "招标公告":
        return _collect_parts(
            record,
            (
                ("项目名称", "project_name"),
                ("采购人", "purchaser"),
                ("预算金额", "budget_amount"),
                ("发布时间", "published_at"),
            ),
        )

    return _collect_parts(
        record,
        (
            ("项目名称", "project_name"),
            ("采购人", "purchaser"),
            ("中标供应商", "winner"),
            ("中标金额", "amount"),
            ("发布时间", "published_at"),
        ),
    )
