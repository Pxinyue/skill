import re
from datetime import date
from pathlib import Path
from typing import List, Optional

from ccgpgov_crawler.client import CCGPSearchClient
from ccgpgov_crawler.exporter import export_to_excel
from ccgpgov_crawler.merge import merge_search_hits
from ccgpgov_crawler.parsers import parse_detail_page, parse_search_results, parse_total_results_count
from ccgpgov_crawler.summarizer import build_summary


ALLOWED_NOTICE_TYPES = {"招标公告", "中标公告", "成交公告"}
INVALID_FILENAME_CHARS = re.compile(r'[\\/:*?"<>|]+')


def normalize_output_filename(keyword: str, today_stamp: Optional[str] = None) -> str:
    safe_keyword = INVALID_FILENAME_CHARS.sub("_", keyword).strip() or "keyword"
    stamp = today_stamp or date.today().strftime("%Y%m%d")
    return f"{safe_keyword}_近一年采购公告汇总_{stamp}.xlsx"


def collect_search_hits(
    keyword: str,
    search_type: int,
    hit_mode: str,
    client: CCGPSearchClient,
    days: int = 365,
    max_pages: Optional[int] = None,
) -> List[dict]:
    first_page_html = client.fetch_search_page(keyword=keyword, search_type=search_type, page_index=1, days=days)
    total_results = parse_total_results_count(first_page_html)
    hits: List[dict] = []
    if total_results is not None:
        if total_results == 0:
            return []

        total_pages = (total_results + 19) // 20
        if max_pages is not None:
            total_pages = min(total_pages, max_pages)

        page_htmls = [(1, first_page_html)]
        for page_index in range(2, total_pages + 1):
            page_htmls.append(
                (
                    page_index,
                    client.fetch_search_page(keyword=keyword, search_type=search_type, page_index=page_index, days=days),
                )
            )

        for _, html in page_htmls:
            page_hits = parse_search_results(html, hit_mode=hit_mode)
            filtered_hits = [hit for hit in page_hits if hit.get("notice_type") in ALLOWED_NOTICE_TYPES]
            hits.extend(filtered_hits)
        return hits

    fallback_limit = max_pages if max_pages is not None else 20
    first_page_hits = parse_search_results(first_page_html, hit_mode=hit_mode)
    hits.extend([hit for hit in first_page_hits if hit.get("notice_type") in ALLOWED_NOTICE_TYPES])

    for page_index in range(2, fallback_limit + 1):
        html = client.fetch_search_page(keyword=keyword, search_type=search_type, page_index=page_index, days=days)
        page_hits = parse_search_results(html, hit_mode=hit_mode)
        if not page_hits:
            break
        filtered_hits = [hit for hit in page_hits if hit.get("notice_type") in ALLOWED_NOTICE_TYPES]
        if not filtered_hits:
            continue
        hits.extend(filtered_hits)

    return hits


def collect_notices(keyword: str, client: Optional[CCGPSearchClient] = None, days: int = 365, max_pages: Optional[int] = None) -> List[dict]:
    crawler_client = client or CCGPSearchClient()

    title_hits = collect_search_hits(
        keyword=keyword,
        search_type=1,
        hit_mode="title",
        client=crawler_client,
        days=days,
        max_pages=max_pages,
    )
    full_text_hits = collect_search_hits(
        keyword=keyword,
        search_type=2,
        hit_mode="full_text",
        client=crawler_client,
        days=days,
        max_pages=max_pages,
    )

    merged_hits = merge_search_hits(title_hits, full_text_hits)
    notices: List[dict] = []

    for hit in merged_hits:
        try:
            detail_html = crawler_client.fetch_detail_page(hit["url"])
            detail = parse_detail_page(detail_html, url=hit["url"])
        except Exception:
            detail = {"url": hit["url"]}

        record = dict(hit)
        record.update({key: value for key, value in detail.items() if value})
        record["keyword"] = keyword
        record["summary"] = build_summary(record)
        notices.append(record)

    return notices


def crawl_keyword(
    keyword: str,
    output_dir: Path,
    client: Optional[CCGPSearchClient] = None,
    days: int = 365,
    max_pages: Optional[int] = None,
    today_stamp: Optional[str] = None,
) -> Path:
    records = collect_notices(keyword=keyword, client=client, days=days, max_pages=max_pages)
    output_path = Path(output_dir) / normalize_output_filename(keyword, today_stamp=today_stamp)
    return export_to_excel(records, output_path)
