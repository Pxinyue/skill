import argparse
import sys
from pathlib import Path

from ccgpgov_crawler.errors import AccessBlockedError
from ccgpgov_crawler.workflow import crawl_keyword


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="抓取中国政府采购网近一年采购公告并导出 Excel。")
    parser.add_argument("keyword", help="搜索关键词，例如公司名称")
    parser.add_argument("--output-dir", default=str(Path.cwd()), help="Excel 输出目录，默认当前工作目录")
    parser.add_argument("--days", type=int, default=365, help="搜索近多少天的数据，默认 365")
    parser.add_argument("--max-pages", type=int, default=None, help="每种搜索类型最多抓取页数；默认按总条数自动计算")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    try:
        output_path = crawl_keyword(
            keyword=args.keyword,
            output_dir=Path(args.output_dir),
            days=args.days,
            max_pages=args.max_pages,
        )
    except AccessBlockedError as exc:
        print(f"中国政府采购网返回了反爬限制页面: {exc}", file=sys.stderr)
        return 1

    print(output_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
