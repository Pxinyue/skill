import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import time
from collections import Counter
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple
from urllib.parse import urljoin

import requests


REPO_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_TAVILY_URL = "https://api.tavily.com/search"
DEFAULT_OUTPUT_DIR = REPO_ROOT / "output" / "leadership-intel"
DEFAULT_MAX_RESULTS = 6
DEFAULT_LEADER_LIMIT = 12
NAME_PATTERN = r"[\u4e00-\u9fa5]{2,3}"
DATE_PATTERN = r"(20\d{2}年(?:\d{1,2}月(?:\d{1,2}日)?)?)"
ORG_STOPWORDS = {
    "领导班子",
    "现任领导",
    "党组成员",
    "党委成员",
    "董事会",
    "经理层",
    "集团公司",
    "人民政府",
    "委员会",
    "办公室",
    "信息中心",
    "事业单位",
    "国有企业",
}
TITLE_KEYWORDS = [
    "党委书记",
    "党组书记",
    "党委副书记",
    "党组副书记",
    "部长",
    "副部长",
    "厅长",
    "副厅长",
    "董事长",
    "副董事长",
    "总经理",
    "副总经理",
    "局长",
    "副局长",
    "主任",
    "副主任",
    "院长",
    "副院长",
    "理事长",
    "书记",
    "副书记",
    "党组成员",
    "党委委员",
    "董事",
    "总会计师",
    "总工程师",
    "首席信息官",
    "首席数据官",
    "信息中心主任",
    "网信办主任",
    "信息化负责人",
]
ROLE_PRIORITY = [
    ("一把手", ["党委书记", "党组书记", "书记", "董事长", "总经理", "部长", "厅长", "局长", "主任", "院长", "理事长"]),
    ("分管领导", ["副董事长", "副总经理", "副部长", "副厅长", "副局长", "副主任", "副院长", "副书记", "党组成员", "党委委员", "总会计师", "总工程师"]),
]
RESPONSIBILITY_RULES = [
    ("数字化/信息化", ["数字化", "信息化", "智慧", "信息中心", "政务服务", "云", "平台建设", "系统建设"]),
    ("数据治理", ["数据", "数据治理", "数据资源", "数据共享", "分类分级", "授权运营", "数据安全"]),
    ("网信/网络安全", ["网信", "网络安全", "安全", "攻防", "合规", "整改", "等保", "密评"]),
    ("项目建设", ["项目", "工程", "建设", "规划", "推进会", "专题会", "预算", "验收"]),
    ("业务管理", ["业务", "服务", "改革", "民生", "运营", "产业", "监管", "治理"]),
]
SOURCE_PRIORITY = [
    ("official", 120),
    ("government_public", 110),
    ("enterprise_disclosure", 105),
    ("official_news", 95),
    ("professional_registry", 85),
    ("registry", 70),
    ("wiki", 30),
    ("other", 20),
]
OFFICIAL_URL_HINTS = (".gov.cn", ".gov", ".edu.cn", ".org.cn", ".com.cn")
REGISTRY_HINTS = ("qcc.com", "tianyancha.com", "aiqicha.baidu.com", "qixin.com")
ENTERPRISE_DISCLOSURE_HINTS = ("cninfo.com.cn", "sse.com.cn", "szse.cn", "hkexnews.hk", "neeq.com.cn")
GOVERNMENT_WHITELIST_HINTS = (".gov.cn", ".gov", "gov.cn", "sasac.gov.cn")
QCC_TOOL_SOURCE_URL = "https://agent.qcc.com/data"
QCC_NAME_KEYS = ("name", "Name", "姓名", "人员姓名", "人员名称", "pname", "personName", "person_name", "keyNoName")
QCC_TITLE_KEYS = ("position", "Position", "职位", "职务", "job", "职务名称", "positionName", "personTitle", "title")
QCC_MANAGER_TITLE_HINTS = ("法定代表人", "董事长", "执行董事", "总经理", "经理", "董事", "监事", "负责人", "高管", "财务负责人")
WIKI_HINTS = ("baike.baidu.com", "wiki", "hudong.com")
MEDIA_HINTS = ("news.qq.com", "new.qq.com", "people.com.cn", "xinhuanet.com", "cctv.com", "china.com.cn")
OFFICIAL_TITLE_HINTS = ("领导班子", "现任领导", "机构领导", "领导简介", "党委", "党组", "董事会", "经理层", "官网")
ACTIVITY_HINTS = ("出席", "主持", "调研", "召开", "参加", "会见", "强调", "指出", "要求", "部署", "推进")
PROJECT_HINTS = ("项目", "工程", "平台", "建设", "数据", "数字化", "安全", "网信", "政策", "方案", "规划", "改革")
LEADERSHIP_PAGE_HINTS = ("领导班子", "领导信息", "领导简介", "本机关负责人", "现任领导", "领导成员", "机构介绍")
BIO_HINTS = ("历任", "曾任", "简历", "履历", "人物履历", "人物经历", "工作履历", "工作经历", "职务任免", "现任")
BAD_SOURCE_HINTS = ("beat365", "365466.com", "zwinkyz.com")
NOISE_PATTERNS = (
    "百度安全验证",
    "百度百科 订阅",
    "使用百度前必读",
    "目录",
    "播报",
    "编辑",
    "new ©",
    "免责声明",
    "版权所有",
    "ICP备",
    "网站地图",
    "登录",
    "注册",
    "Untitled",
    "P 26",
    "P 28",
    "封面人物",
    "奋斗新时代",
)
QUERY_PRIORITY_BONUS = {
    "official_profile": 40,
    "bio": 35,
    "bio_general": 28,
    "appointment": 26,
    "activity": 24,
    "public_statement": 24,
    "customer_official_news": 22,
    "customer_baike": 20,
    "disclosure_resume": 30,
    "executive_database": 22,
    "same_person_check": 28,
    "focus_1": 18,
    "focus_2": 18,
    "wiki": 16,
}
CUSTOMER_ABBREVIATIONS = {
    "人力资源和社会保障": "人社",
    "人力资源社会保障": "人社",
    "互联网信息办公室": "网信办",
    "大数据发展管理局": "大数据局",
    "政务服务和数据管理局": "政数局",
}


SPECIAL_CUSTOMER_SOURCE_RULES: Dict[str, Dict[str, Any]] = {}
SPECIAL_CUSTOMER_PRESET_LEADERS: Dict[str, Dict[str, Any]] = {}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="客户高层领导公开信息搜集与画像生成")
    parser.add_argument("customer_name", help="客户名称，例如 某省大数据中心")
    parser.add_argument("--focus", default="", help="关注主题，多个主题可用逗号分隔，例如 数据安全,数字化")
    parser.add_argument("--official-roster-url", default="", help="官方领导班子或本机关负责人页面 URL，提供时优先使用")
    parser.add_argument("--leader-limit", type=int, default=DEFAULT_LEADER_LIMIT, help="默认输出重点画像人数，建议 8-12；不是全量人员清单上限")
    parser.add_argument("--deep-profile-count", type=int, default=6, help="对排序靠前的关键人员补充百科/年报/公告/高管库等个人情况，默认前 6 位")
    parser.add_argument("--tavily-api-key", default=os.environ.get("TAVILY_API_KEY", ""), help="Tavily API Key")
    parser.add_argument("--output-dir", default=str(DEFAULT_OUTPUT_DIR), help="输出目录")
    parser.add_argument("--max-results", type=int, default=DEFAULT_MAX_RESULTS, help="每轮 Tavily 最大返回条数")
    parser.add_argument("--search-payload", default="", help="读取本地搜索结果 JSON，离线复盘时使用")
    parser.add_argument("--save-search-payload", default="", help="将联网搜索结果保存为 JSON")
    parser.add_argument(
        "--enable-qcc-agent",
        action="store_true",
        default=os.environ.get("QCC_AGENT_ENABLE", "") == "1" or bool(os.environ.get("QCC_AGENT_API_KEY", "")),
        help="Enable Qichacha Agent/CLI as an optional enterprise-side professional source; skip automatically when unavailable.",
    )
    parser.add_argument("--qcc-cli", default=os.environ.get("QCC_CLI", "qcc"), help="Qichacha Agent CLI command or full path.")
    parser.add_argument("--qcc-api-key", default=os.environ.get("QCC_AGENT_API_KEY", ""), help="Qichacha Agent API key; used only for CLI authorization.")
    parser.add_argument("--skip-qcc-init", action="store_true", help="Skip qcc init when the local CLI is already authorized.")
    return parser


def split_focus_terms(raw_focus: str) -> List[str]:
    terms = [item.strip() for item in re.split(r"[，,、/]+", raw_focus) if item.strip()]
    return terms


def build_customer_aliases(customer_name: str) -> List[str]:
    aliases = {customer_name.strip()}
    stripped = customer_name.strip()
    for prefix in ("浙江省", "浙江", "省", "市"):
        if stripped.startswith(prefix) and len(stripped) > len(prefix) + 2:
            aliases.add(stripped[len(prefix):])
    for source, target in CUSTOMER_ABBREVIATIONS.items():
        if source in customer_name:
            aliases.add(customer_name.replace(source, target))
            stripped_variant = stripped.replace(source, target)
            aliases.add(stripped_variant)
            for prefix in ("浙江省", "浙江", "省", "市"):
                if stripped_variant.startswith(prefix) and len(stripped_variant) > len(prefix) + 2:
                    aliases.add(stripped_variant[len(prefix):])
    aliases = {alias for alias in aliases if alias and len(alias) >= 3}
    return sorted(aliases, key=len, reverse=True)


def normalize_url_for_compare(url: str) -> str:
    value = (url or "").strip()
    if not value:
        return ""
    return value.split("#", 1)[0].rstrip("/").lower()


def get_special_customer_source_rule(customer_name: str) -> Dict[str, Any]:
    normalized_name = (customer_name or "").strip()
    for key, rule in SPECIAL_CUSTOMER_SOURCE_RULES.items():
        if key in normalized_name:
            return rule
    return {}


def get_special_customer_preset(customer_name: str) -> Dict[str, Any]:
    normalized_name = (customer_name or "").strip()
    for key, preset in SPECIAL_CUSTOMER_PRESET_LEADERS.items():
        if key in normalized_name:
            return preset
    return {}


def build_special_customer_official_leaders(customer_name: str) -> List[Dict[str, Any]]:
    preset = get_special_customer_preset(customer_name)
    if not preset:
        return []
    base_sources = finalize_source_links(customer_name, [], limit=2, force_required=True)
    leaders: List[Dict[str, Any]] = []
    for item in preset.get("leaders", []):
        leaders.append(
            {
                "name": item["name"],
                "current_title": item["current_title"],
                "role_label": item["role_label"],
                "responsibilities": item.get("responsibilities", []),
                "appointment_time": "未公开确认",
                "past_experience": [],
                "public_activities": [],
                "project_policy_links": [item.get("duty_text", "")] if item.get("duty_text") else [],
                "possible_concerns": [],
                "sources": base_sources,
                "confidence": "高",
                "ranking_score": item.get("ranking_score", 10000),
                "focus_matches": [],
                "office_phone": item.get("office_phone", ""),
                "duty_text": item.get("duty_text", ""),
            }
        )
    return leaders


def finalize_source_links(customer_name: str, sources: List[Dict[str, str]], limit: int = 4, force_required: bool = False) -> List[Dict[str, str]]:
    rule = get_special_customer_source_rule(customer_name)
    if not rule:
        return select_source_links(sources, limit=limit)

    existing_by_url = {}
    for source in sources:
        url = source.get("url", "")
        if not url or is_bad_source(url, source.get("title", "")):
            continue
        existing_by_url[normalize_url_for_compare(url)] = source

    result: List[Dict[str, str]] = []
    seen = set()
    for preferred in rule.get("preferred_sources", []):
        key = normalize_url_for_compare(preferred.get("url", ""))
        if not key or key in seen:
            continue
        seen.add(key)
        matched = existing_by_url.get(key, {})
        if matched or force_required:
            result.append(
                {
                    "title": matched.get("title") or preferred.get("title", ""),
                    "url": matched.get("url") or preferred.get("url", ""),
                    "source_type": matched.get("source_type") or preferred.get("source_type", ""),
                }
            )
        if len(result) >= limit:
            break
    return result[:limit]


def build_seed_urls(customer_name: str, official_roster_url: str) -> List[str]:
    urls: List[str] = []
    if official_roster_url:
        urls.append(official_roster_url)
    deduped: List[str] = []
    seen = set()
    for url in urls:
        key = normalize_url_for_compare(url)
        if not key or key in seen:
            continue
        seen.add(key)
        deduped.append(url)
    return deduped


def build_queries(customer_name: str, focus_terms: List[str]) -> List[Dict[str, str]]:
    queries = [
        {"id": "leadership_roster", "query": f"{customer_name} 领导班子"},
        {"id": "current_leaders", "query": f"{customer_name} 现任领导"},
        {"id": "party_leaders", "query": f"{customer_name} 党委 党组 领导"},
        {"id": "digital_leaders", "query": f"{customer_name} 信息化 数字化 分管领导"},
        {"id": "security_leaders", "query": f"{customer_name} 数据安全 网信 网络安全 分管领导"},
        {"id": "appointment_notices", "query": f"{customer_name} 任免 通知 领导"},
        {"id": "official_news", "query": f"{customer_name} 领导 调研 讲话 活动"},
        {"id": "government_whitelist", "query": f"{customer_name} 领导班子 现任领导 site:gov.cn"},
        {"id": "customer_public_speech", "query": f"{customer_name} 领导 讲话 公开发言 采访"},
        {"id": "enterprise_management", "query": f"{customer_name} 管理团队 董事会 经理层 高级管理人员"},
        {"id": "enterprise_disclosure", "query": f"{customer_name} 年报 董监高 公司治理 管理层"},
        {"id": "professional_registry", "query": f"{customer_name} 企查查 天眼查 爱企查 高管 法定代表人"},
        {"id": "business_pressure", "query": f"{customer_name} 年报 业绩说明会 经营压力 营收 利润 费用率 现金流 回款"},
        {"id": "strategy_keywords", "query": f"{customer_name} 公开发言 主题词 AI 数据安全 安全运营 技术发展"},
    ]
    for index, focus_term in enumerate(focus_terms, start=1):
        queries.append(
            {
                "id": f"focus_{index}",
                "query": f"{customer_name} {focus_term} 分管领导 讲话 活动",
            }
        )
        queries.append(
            {
                "id": f"focus_trend_{index}",
                "query": f"{focus_term} 最新技术发展 AI 安全 2026 白皮书 标准 趋势",
            }
        )
    return queries


def build_leader_queries(customer_name: str, leader_name: str, focus_terms: List[str]) -> List[Dict[str, str]]:
    queries = [
        {"id": "official_profile", "query": f"{customer_name} {leader_name} 我的职责 我的简历"},
        {"id": "bio", "query": f"{customer_name} {leader_name} 履历 简历"},
        {"id": "bio_general", "query": f"{leader_name} 简历 履历"},
        {"id": "appointment", "query": f"{customer_name} {leader_name} 任命 任职"},
        {"id": "activity", "query": f"{customer_name} {leader_name} 讲话 活动 调研"},
        {"id": "public_statement", "query": f"{customer_name} {leader_name} 公开发言 讲话 采访 观点"},
        {"id": "customer_official_news", "query": f"{customer_name} {leader_name} 官网 新闻 活动"},
        {"id": "leader_business_pressure", "query": f"{customer_name} {leader_name} 年报 业绩说明会 经营 压力 关注"},
        {"id": "wiki", "query": f"{leader_name} 百度百科"},
        {"id": "customer_baike", "query": f"{customer_name} {leader_name} 百度百科 人物"},
        {"id": "disclosure_resume", "query": f"{customer_name} {leader_name} 年报 招股书 董事 高级管理人员 简历 主要工作经历"},
        {"id": "executive_database", "query": f"{customer_name} {leader_name} 个人简介 高管"},
        {"id": "same_person_check", "query": f"\"{leader_name}\" \"{customer_name}\" \"现任\""},
    ]
    for index, focus_term in enumerate(focus_terms[:2], start=1):
        queries.append({"id": f"focus_{index}", "query": f"{customer_name} {leader_name} {focus_term}"})
        queries.append({"id": f"focus_trend_{index}", "query": f"{leader_name} {focus_term} 公开观点 最新技术发展"})
    return queries


def search_tavily(api_key: str, query: str, max_results: int) -> Dict[str, Any]:
    payload = {
        "api_key": api_key,
        "query": query,
        "search_depth": "advanced",
        "max_results": max_results,
    }
    for attempt in range(2):
        response = requests.post(DEFAULT_TAVILY_URL, json=payload, timeout=60)
        if response.ok:
            return response.json()
        if response.status_code in (429, 432) and attempt == 0:
            time.sleep(2)
            continue
        if response.status_code in (429, 432):
            return {"results": []}
        response.raise_for_status()
    return {"results": []}


def run_searches(customer_name: str, api_key: str, max_results: int, focus_terms: List[str]) -> Dict[str, Any]:
    payload: Dict[str, Any] = {"customer_name": customer_name, "queries": []}
    for query_item in build_queries(customer_name, focus_terms):
        result = search_tavily(api_key, query_item["query"], max_results)
        payload["queries"].append(
            {
                "id": query_item["id"],
                "query": query_item["query"],
                "results": result.get("results", []),
            }
        )
    return payload


def run_leader_searches(customer_name: str, leader_names: List[str], api_key: str, max_results: int, focus_terms: List[str]) -> Dict[str, List[Dict[str, Any]]]:
    result: Dict[str, List[Dict[str, Any]]] = {}
    for leader_name in leader_names:
        entries: List[Dict[str, Any]] = []
        for query_item in build_leader_queries(customer_name, leader_name, focus_terms):
            payload = search_tavily(api_key, query_item["query"], max_results=max_results)
            entries.append(
                {
                    "id": query_item["id"],
                    "query": query_item["query"],
                    "results": payload.get("results", []),
                }
            )
        result[leader_name] = entries
    return result


def load_search_payload(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def save_search_payload(path: Path, payload: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def normalize_text(text: str) -> str:
    return re.sub(r"\s+", " ", text or "").strip()


def is_relevant_result(customer_aliases: List[str], title: str, content: str, url: str) -> bool:
    content_head = (content or "")[:500]
    merged = f"{title} {content_head} {url}"
    for alias in customer_aliases:
        if alias in merged:
            return True
    compact = merged.replace(" ", "")
    for alias in customer_aliases:
        if alias.replace(" ", "") in compact:
            return True
    return False


def html_to_text(html: str) -> str:
    text = re.sub(r"<script[\s\S]*?</script>", " ", html or "", flags=re.I)
    text = re.sub(r"<style[\s\S]*?</style>", " ", text, flags=re.I)
    text = re.sub(r"<[^>]+>", " ", text)
    return normalize_text(text)


def extract_leadership_fragment(html: str) -> str:
    match = re.search(r'<div class="center clearfix">([\s\S]*?)<div class="bottom">', html or "", flags=re.I)
    if match:
        return match.group(1)
    return html or ""


def fetch_url(url: str) -> str:
    response = requests.get(url, timeout=30)
    response.raise_for_status()
    return response.text


def is_bad_source(url: str, title: str = "") -> bool:
    merged = f"{url} {title}".lower()
    return any(hint in merged for hint in BAD_SOURCE_HINTS)


def extract_section_text(text: str, start_label: str, end_labels: Tuple[str, ...], max_length: int = 240) -> str:
    if not text or start_label not in text:
        return ""
    tail = text.split(start_label, 1)[1]
    end_indexes = [tail.find(label) for label in end_labels if label and tail.find(label) != -1]
    if end_indexes:
        tail = tail[: min(end_indexes)]
    return normalize_text(tail)[:max_length]


def is_attachment_url(url: str) -> bool:
    url_lower = (url or "").lower()
    return url_lower.endswith(".pdf") or "/attach/" in url_lower


def is_official_leadership_result(customer_aliases: List[str], title: str, content: str, url: str) -> bool:
    if not is_relevant_result(customer_aliases, title, content, url):
        return False
    source_type, _ = classify_source(url, title, content)
    if source_type not in ("official", "government_public", "official_news"):
        return False
    merged = f"{title} {content} {url}"
    return any(hint in merged for hint in LEADERSHIP_PAGE_HINTS)


def extract_title_for_name(text: str, name: str) -> str:
    patterns = [
        rf"{re.escape(name)}\s*([^\n。]{0,40}(?:{TITLE_PATTERN})[^\n。]{0,30})",
        rf"((?:{TITLE_PATTERN})[^\n。]{0,30})\s*[:：]?\s*{re.escape(name)}",
    ]
    for pattern in patterns:
        match = re.search(pattern, text)
        if match:
            value = clean_title(match.group(1))
            if value:
                return value
    return ""


def extract_duties_for_name(text: str, name: str) -> str:
    patterns = [
        rf"{re.escape(name)}[^。]{0,120}(?:分管|负责)[^。]{0,160}",
        rf"(?:我的职责|工作分工)[^。]{0,200}",
    ]
    for pattern in patterns:
        match = re.search(pattern, text)
        if match:
            return normalize_text(match.group(0))
    return ""


def extract_official_title_for_name(text: str, name: str) -> str:
    patterns = [
        rf"([^\n。:：]{{0,80}}?(?:{TITLE_PATTERN})[^\n。:：]{{0,30}}?)[：:]\s*{re.escape(name)}",
        rf"{re.escape(name)}\s+([^\n。]{{0,60}}?)\s+我的职责",
        rf"{re.escape(name)}\s+([^\n。]{{0,40}}?(?:{TITLE_PATTERN})[^\n。]{{0,20}}?)\s+我的简历",
    ]
    for pattern in patterns:
        matches = list(re.finditer(pattern, text))
        for match in reversed(matches):
            value = clean_title(match.group(1))
            if value and any(keyword in value for keyword in TITLE_KEYWORDS):
                return value
    return ""


def extract_detail_page_title(text: str, name: str) -> str:
    if "我的职责" in text:
        prefix = text.split("我的职责", 1)[0]
        index = prefix.rfind(name)
        if index != -1:
            value = clean_title(prefix[index + len(name):].strip())
            if value and any(keyword in value for keyword in TITLE_KEYWORDS):
                return value
    patterns = [
        rf"{re.escape(name)}.*?{re.escape(name)}\s+([^。]+?)\s+我的职责",
        rf"{re.escape(name)}\s+([^。]+?)\s+我的职责",
        rf"{re.escape(name)}\s+([^。]+?)\s+我的简历",
    ]
    for pattern in patterns:
        match = re.search(pattern, text)
        if match:
            value = clean_title(match.group(1))
            if value and any(keyword in value for keyword in TITLE_KEYWORDS):
                return value
    return ""


def extract_official_roster(customer_name: str, payload: Dict[str, Any], seed_urls: List[str] | None = None) -> List[Dict[str, Any]]:
    preset_leaders = build_special_customer_official_leaders(customer_name)
    if preset_leaders:
        return preset_leaders
    customer_aliases = build_customer_aliases(customer_name)
    candidate_urls: List[str] = []
    seen_urls = set()
    for url in seed_urls or []:
        normalized = normalize_text(url)
        if normalized and normalized not in seen_urls:
            seen_urls.add(normalized)
            candidate_urls.append(normalized)
    for query_item in payload.get("queries", []):
        if query_item.get("id") not in ("leadership_roster", "current_leaders", "party_leaders"):
            continue
        for result in query_item.get("results", []):
            title = normalize_text(result.get("title", ""))
            content = normalize_text(result.get("content", ""))
            url = normalize_text(result.get("url", ""))
            if not url or url in seen_urls:
                continue
            if not is_official_leadership_result(customer_aliases, title, content, url):
                continue
            seen_urls.add(url)
            candidate_urls.append(url)

    leaders: Dict[str, Dict[str, Any]] = {}
    for url in candidate_urls[:3]:
        try:
            html = fetch_url(url)
        except requests.RequestException:
            continue
        leadership_html = extract_leadership_fragment(html)
        page_text = html_to_text(leadership_html)
        link_candidates = re.findall(r'<a[^>]+href=["\']([^"\']+)["\'][^>]*>(.*?)</a>', leadership_html, flags=re.I | re.S)
        name_to_link: Dict[str, str] = {}
        for href, inner in link_candidates:
            anchor_text = html_to_text(inner)
            if looks_like_person_name(anchor_text):
                name_to_link[anchor_text] = urljoin(url, href)
        for img_alt in re.findall(r'alt=["\']([^"\']+)["\']', leadership_html, flags=re.I):
            alt_text = normalize_text(img_alt)
            if looks_like_person_name(alt_text):
                name_to_link.setdefault(alt_text, url)
        for colon_name in re.findall(r"[：:]\s*(" + NAME_PATTERN + r")", page_text):
            if looks_like_person_name(colon_name):
                name_to_link.setdefault(colon_name, url)

        for name, profile_url in name_to_link.items():
            title = extract_official_title_for_name(page_text, name)
            duty_text = ""
            detail_text = page_text
            if profile_url and profile_url != url:
                try:
                    detail_html = fetch_url(profile_url)
                    detail_text = html_to_text(detail_html)
                except requests.RequestException:
                    detail_text = page_text
            if profile_url and profile_url != url:
                title = extract_detail_page_title(detail_text, name) or title
            if not title:
                title = extract_official_title_for_name(detail_text, name)
            duty_text = extract_section_text(detail_text, "我的职责", ("我的简历", "工作简历", "简历")) or extract_duties_for_name(detail_text, name)
            bio_text = extract_section_text(detail_text, "我的简历", ("返回顶部", "打印", "关闭窗口", "上一篇", "下一篇"))
            if profile_url == url and duty_text and name not in duty_text:
                duty_text = ""
            if not title:
                continue
            responsibilities = infer_responsibilities(duty_text or detail_text[:240])
            leaders[name] = {
                "name": name,
                "current_title": title,
                "role_label": infer_role_label(title, responsibilities),
                "responsibilities": responsibilities,
                "appointment_time": "未公开确认",
                "past_experience": [bio_text] if bio_text else [],
                "public_activities": [],
                "project_policy_links": [duty_text] if duty_text else [],
                "possible_concerns": [],
                "sources": [{"title": "官方领导班子页面", "url": profile_url or url, "source_type": "government_public"}],
                "confidence": "高",
                "ranking_score": 10000,
                "focus_matches": [],
            }
    return list(leaders.values())


def classify_source(url: str, title: str, content: str) -> Tuple[str, int]:
    merged = f"{title} {content}".lower()
    url_lower = (url or "").lower()
    if any(hint in url_lower for hint in ENTERPRISE_DISCLOSURE_HINTS):
        return ("enterprise_disclosure", source_score("enterprise_disclosure"))
    if any(hint in url_lower for hint in REGISTRY_HINTS):
        return ("professional_registry", source_score("professional_registry"))
    if any(hint in url_lower for hint in WIKI_HINTS):
        return ("wiki", source_score("wiki"))
    if any(hint in url_lower for hint in MEDIA_HINTS):
        return ("official_news", source_score("official_news"))
    if ".gov" in url_lower or ".gov.cn" in url_lower:
        return ("government_public", source_score("government_public"))
    if any(hint in url_lower for hint in OFFICIAL_URL_HINTS) and any(keyword in title for keyword in OFFICIAL_TITLE_HINTS):
        return ("official", source_score("official"))
    if any(keyword in title for keyword in OFFICIAL_TITLE_HINTS):
        return ("official_news", source_score("official_news"))
    if any(keyword in merged for keyword in ("集团", "公司", "官网", "党委", "党组", "局", "厅", "院")):
        return ("official_news", source_score("official_news"))
    return ("other", source_score("other"))


def source_score(source_type: str) -> int:
    for label, value in SOURCE_PRIORITY:
        if label == source_type:
            return value
    return 0


def looks_like_person_name(name: str) -> bool:
    if not re.fullmatch(NAME_PATTERN, name or ""):
        return False
    if name in ORG_STOPWORDS:
        return False
    if name in TITLE_KEYWORDS:
        return False
    if any(token in name for token in ("公司", "集团", "政府", "党组", "党委", "领导", "董事", "主任")):
        return False
    if any(token in name for token in ("主持", "带队", "调研", "推进", "检查", "会议", "工作", "数字", "网络", "强调", "指出", "要求")):
        return False
    if name.startswith(("在", "于", "赴", "到", "全", "专题")):
        return False
    if name.endswith(("长", "书记", "主任", "经理", "成员", "委员", "院长", "部长", "厅", "局", "委", "办", "市", "县", "区", "省")):
        return False
    return True


def build_title_pattern() -> str:
    escaped = [re.escape(item) for item in sorted(TITLE_KEYWORDS, key=len, reverse=True)]
    return "|".join(escaped)


TITLE_PATTERN = build_title_pattern()
COMPOUND_TITLE_PATTERN = rf"(?:{TITLE_PATTERN})(?:[、,，兼/](?:{TITLE_PATTERN}))*"


def extract_candidates(snippet: str) -> List[Tuple[str, str, str]]:
    candidates: List[Tuple[str, str, str]] = []
    patterns = [
        re.compile(rf"(?<![\u4e00-\u9fa5])(?P<name>{NAME_PATTERN})(?:同志)?[，、\s]*(?P<title>{COMPOUND_TITLE_PATTERN})"),
        re.compile(rf"(?P<title>{COMPOUND_TITLE_PATTERN})[：:\s]*(?P<name>{NAME_PATTERN})(?![\u4e00-\u9fa5])"),
    ]
    for pattern in patterns:
        for match in pattern.finditer(snippet):
            name = (match.group("name") or "").strip()
            title = clean_title(match.group("title") or "")
            if not looks_like_person_name(name):
                continue
            if not title:
                continue
            context = extract_sentence(snippet, match.start(), match.end())
            candidates.append((name, title, context))
    return candidates


def clean_title(raw_title: str) -> str:
    title = normalize_text(raw_title)
    title = re.sub(r"^[，、：:]+|[，、：:]+$", "", title)
    title = re.sub(r"^(本机关负责人|其他领导|领导成员)\s*", "", title)
    for noise in ("近日", "在", "赴", "带队", "专题", "会议", "调研"):
        if title.startswith(noise):
            title = title[len(noise):].strip()
    return title[:30]


def extract_sentence(snippet: str, start: int, end: int) -> str:
    left = max(snippet.rfind("。", 0, start), snippet.rfind("！", 0, start), snippet.rfind("？", 0, start), snippet.rfind("；", 0, start))
    right_candidates = [idx for idx in (snippet.find("。", end), snippet.find("！", end), snippet.find("？", end), snippet.find("；", end)) if idx != -1]
    right = min(right_candidates) if right_candidates else len(snippet)
    segment = snippet[left + 1:right].strip()
    return segment or snippet[max(0, start - 20): min(len(snippet), end + 30)].strip()


def extract_dates(text: str) -> List[str]:
    return re.findall(DATE_PATTERN, text or "")


def infer_responsibilities(text: str) -> List[str]:
    hits: List[str] = []
    for label, keywords in RESPONSIBILITY_RULES:
        if any(keyword in text for keyword in keywords):
            hits.append(label)
    return hits


def infer_role_label(title: str, responsibilities: Iterable[str]) -> str:
    deputy_keywords = ROLE_PRIORITY[1][1]
    if any(keyword in title for keyword in deputy_keywords):
        return "分管领导"
    for label, keywords in ROLE_PRIORITY:
        if any(keyword in title for keyword in keywords):
            if label == "一把手" and any(tag in responsibilities for tag in ("数字化/信息化", "数据治理", "网信/网络安全")):
                return "一把手/重点关注"
            return label
    if any(tag in responsibilities for tag in ("数字化/信息化", "数据治理", "网信/网络安全")):
        return "分管领导"
    return "业务负责人"


def sanitize_filename(name: str) -> str:
    return re.sub(r'[\\/:*?"<>|]+', "_", name).strip() or "customer"


def extract_leaders(customer_name: str, payload: Dict[str, Any], focus_terms: List[str]) -> List[Dict[str, Any]]:
    customer_aliases = build_customer_aliases(customer_name)
    leaders: Dict[str, Dict[str, Any]] = {}
    for query_item in payload.get("queries", []):
        query_id = query_item.get("id", "")
        for result in query_item.get("results", []):
            title = normalize_text(result.get("title", ""))
            content = normalize_text(result.get("content", ""))
            url = normalize_text(result.get("url", ""))
            if not is_relevant_result(customer_aliases, title, content, url):
                continue
            snippet = " ".join(part for part in [title, content] if part)
            if not snippet:
                continue
            source_type, base_score = classify_source(url, title, content)
            candidates = extract_candidates(snippet)
            for name, matched_title, context in candidates:
                leader = leaders.setdefault(
                    name,
                    {
                        "name": name,
                        "title_scores": Counter(),
                        "responsibility_scores": Counter(),
                        "dates": Counter(),
                        "source_links": [],
                        "activities": [],
                        "project_policy_links": [],
                        "evidence": [],
                        "focus_hits": Counter(),
                        "source_types": Counter(),
                    },
                )
                title_bonus = 35 if query_id in ("leadership_roster", "current_leaders", "party_leaders") else 15
                total_score = base_score + title_bonus
                leader["title_scores"][matched_title] += total_score
                leader["source_types"][source_type] += 1
                for item in extract_dates(context):
                    leader["dates"][item] += total_score
                for responsibility in infer_responsibilities(context):
                    leader["responsibility_scores"][responsibility] += total_score
                for focus_term in focus_terms:
                    if focus_term and focus_term in context:
                        leader["focus_hits"][focus_term] += total_score
                evidence_item = {
                    "query_id": query_id,
                    "title": title,
                    "url": url,
                    "content": content,
                    "source_type": source_type,
                    "source_score": total_score,
                    "context": context,
                }
                leader["evidence"].append(evidence_item)
                leader["source_links"].append({"title": title or matched_title, "url": url, "source_type": source_type})
                if any(keyword in context for keyword in ACTIVITY_HINTS):
                    leader["activities"].append(evidence_item)
                if any(keyword in context for keyword in PROJECT_HINTS):
                    leader["project_policy_links"].append(evidence_item)
    records = [finalize_leader_record(customer_name, item, focus_terms) for item in leaders.values()]
    records = [record for record in records if record["current_title"]]
    return sorted(records, key=lambda item: item["ranking_score"], reverse=True)


def unique_sources(items: List[Dict[str, Any]], limit: int = 5) -> List[Dict[str, str]]:
    result: List[Dict[str, str]] = []
    seen = set()
    for item in sorted(items, key=lambda entry: entry.get("source_score", 0), reverse=True):
        if is_bad_source(item.get("url", ""), item.get("title", "")):
            continue
        key = (item.get("title", ""), item.get("url", ""))
        if key in seen:
            continue
        seen.add(key)
        result.append(
            {
                "title": item.get("title", ""),
                "url": item.get("url", ""),
                "source_type": item.get("source_type", ""),
            }
        )
        if len(result) >= limit:
            break
    return result


def pick_top_text(items: List[Dict[str, Any]], limit: int = 2) -> List[str]:
    selected: List[str] = []
    seen = set()
    for item in sorted(items, key=lambda entry: entry.get("source_score", 0), reverse=True):
        snippet = clean_evidence_text(item.get("context") or item.get("content") or item.get("title") or "")
        if not is_substantive_sentence(snippet):
            continue
        if not snippet or snippet in seen:
            continue
        selected.append(snippet)
        seen.add(snippet)
        if len(selected) >= limit:
            break
    return selected


def trim_summary(text: str, limit: int = 48) -> str:
    text = normalize_text(text)
    text = re.sub(r"^[#>\-\|\s]+", "", text)
    text = text.replace("...", "，")
    if len(text) <= limit:
        return text
    return text[:limit].rstrip("，,；;。") + "。"


def split_sentences(text: str) -> List[str]:
    normalized = normalize_text(text)
    parts = re.split(r"[。！？；]", normalized)
    return [part.strip() for part in parts if part.strip()]


def clean_evidence_text(text: str) -> str:
    cleaned = normalize_text(text)
    cleaned = re.sub(r"\[[^\]]+\]", " ", cleaned)
    cleaned = re.sub(r"^#+\s*", "", cleaned)
    for marker in NOISE_PATTERNS:
        cleaned = cleaned.replace(marker, " ")
    cleaned = re.sub(r"\s+", " ", cleaned)
    return cleaned.strip(" |#-")


def is_substantive_sentence(text: str, leader_name: str = "") -> bool:
    candidate = clean_evidence_text(text)
    if not candidate or len(candidate) < 10:
        return False
    if leader_name and leader_name not in candidate and len(candidate) < 18:
        return False
    if candidate.count("百度百科") >= 1 and len(candidate) < 24:
        return False
    if any(marker in candidate for marker in NOISE_PATTERNS):
        return False
    if "http" in candidate.lower():
        return False
    if candidate.count("##") >= 1:
        return False
    return True


def dedupe_texts(items: List[str], limit: int = 3) -> List[str]:
    result: List[str] = []
    seen = set()
    for item in items:
        cleaned = clean_evidence_text(item)
        if not cleaned or cleaned in seen:
            continue
        seen.add(cleaned)
        result.append(cleaned)
        if len(result) >= limit:
            break
    return result


def contains_customer_alias(text: str, customer_aliases: List[str]) -> bool:
    merged = clean_evidence_text(text)
    return any(alias in merged for alias in customer_aliases)


def is_good_bio_text(text: str) -> bool:
    candidate = clean_evidence_text(text)
    if not is_substantive_sentence(candidate):
        return False
    if not any(marker in candidate for marker in BIO_HINTS + ("男，", "女，", "汉族", "中共党员")):
        return False
    return True


def is_good_activity_text(text: str, leader_name: str) -> bool:
    candidate = clean_evidence_text(text)
    if not is_substantive_sentence(candidate, leader_name):
        return False
    if not any(marker in candidate for marker in ACTIVITY_HINTS):
        return False
    if any(marker in candidate for marker in ("封面人物", "奋斗新时代", "目录")):
        return False
    return True


def is_good_project_text(text: str) -> bool:
    candidate = clean_evidence_text(text)
    if not is_substantive_sentence(candidate):
        return False
    if not any(marker in candidate for marker in PROJECT_HINTS + ("分管", "负责", "联系")):
        return False
    return True


def is_high_value_leader_url(url: str, source_type: str) -> bool:
    url_lower = (url or "").lower()
    if is_bad_source(url):
        return False
    if source_type in ("official", "government_public", "wiki"):
        return True
    return any(hint in url_lower for hint in MEDIA_HINTS)


def select_fetch_candidates(query_payloads: List[Dict[str, Any]], leader_name: str) -> List[Dict[str, Any]]:
    candidates: List[Dict[str, Any]] = []
    seen = set()
    for query_item in query_payloads:
        for result in query_item.get("results", []):
            title = normalize_text(result.get("title", ""))
            content = normalize_text(result.get("content", ""))
            url = normalize_text(result.get("url", ""))
            if not url or leader_name not in f"{title} {content}":
                continue
            source_type, base_score = classify_source(url, title, content)
            if not is_high_value_leader_url(url, source_type):
                continue
            key = url
            if key in seen:
                continue
            seen.add(key)
            candidates.append(
                {
                    "query_id": query_item.get("id", ""),
                    "title": title,
                    "content": content,
                    "url": url,
                    "source_type": source_type,
                    "source_score": base_score + QUERY_PRIORITY_BONUS.get(query_item.get("id", ""), 12),
                }
            )
    candidates.sort(key=lambda item: item["source_score"], reverse=True)
    return candidates[:8]


def fetch_candidate_page(candidate: Dict[str, Any]) -> Dict[str, Any]:
    url_lower = candidate["url"].lower()
    if url_lower.endswith(".pdf") or "/attach/" in url_lower:
        page_text = clean_evidence_text(f"{candidate.get('title', '')} {candidate.get('content', '')}")
        result = dict(candidate)
        result["page_text"] = page_text
        return result
    try:
        html = fetch_url(candidate["url"])
        page_text = clean_evidence_text(html_to_text(html))[:8000]
    except requests.RequestException:
        page_text = clean_evidence_text(f"{candidate.get('title', '')} {candidate.get('content', '')}")
    if not page_text or len(page_text) < 80 or "百度安全验证" in page_text:
        page_text = clean_evidence_text(f"{candidate.get('title', '')} {candidate.get('content', '')}")
    result = dict(candidate)
    result["page_text"] = page_text
    return result


def pick_sentences(text: str, leader_name: str, keywords: Tuple[str, ...], limit: int = 2, allow_without_name: bool = False) -> List[str]:
    selected: List[str] = []
    for sentence in split_sentences(text):
        if not allow_without_name and leader_name not in sentence:
            continue
        if keywords and not any(keyword in sentence for keyword in keywords):
            continue
        if not is_substantive_sentence(sentence, leader_name):
            continue
        cleaned = trim_summary(clean_evidence_text(sentence), limit=80)
        if cleaned not in selected:
            selected.append(cleaned)
        if len(selected) >= limit:
            break
    return selected


def prefer_sentence(text: str, name: str = "") -> str:
    normalized = clean_evidence_text(text)
    parts = re.split(r"[。！？；]", normalized)
    candidates = [part.strip() for part in parts if part.strip()]
    if name:
        for part in candidates:
            if name in part and is_substantive_sentence(part, name):
                return part
    for part in candidates:
        if is_substantive_sentence(part, name):
            return part
    return normalized if is_substantive_sentence(normalized, name) else ""


def build_bio_summary(name: str, past_experience: List[str], sources: List[Dict[str, str]]) -> str:
    for item in past_experience:
        sentence = prefer_sentence(item, name)
        if sentence:
            return trim_summary(sentence, limit=60)
    return "公开履历信息有限，建议后续补充官方简历或权威人物资料。"


def build_activity_summary(name: str, activities: List[str], concerns: List[Dict[str, str]]) -> str:
    for item in activities:
        sentence = prefer_sentence(item, name)
        if sentence:
            return trim_summary(sentence, limit=72)
    if concerns:
        concern_text = concerns[0]["point"].lstrip("关注")
        return trim_summary(f"近期公开活动披露有限，结合现有公开信息，重点关注{concern_text}", limit=64)
    return "近期公开活动披露有限。"


def build_project_policy_summary(project_links: List[str], responsibilities: List[str], concerns: List[Dict[str, str]]) -> str:
    for item in project_links:
        sentence = prefer_sentence(item)
        if sentence:
            return trim_summary(sentence, limit=72)
    if responsibilities:
        return trim_summary(f"当前更可能与{'、'.join(responsibilities[:2])}相关项目和政策推进有关。", limit=48)
    if concerns:
        return trim_summary(concerns[0]["basis"], limit=48)
    return "暂未检索到明确的项目或政策关联公开材料。"


def select_source_links(sources: List[Dict[str, str]], limit: int = 4) -> List[Dict[str, str]]:
    result: List[Dict[str, str]] = []
    seen = set()
    for source in sources:
        if is_bad_source(source.get("url", ""), source.get("title", "")):
            continue
        key = (source.get("title", ""), source.get("url", ""))
        if key in seen:
            continue
        seen.add(key)
        result.append(source)
        if len(result) >= limit:
            break
    return result


def pick_top_value(counter: Counter) -> str:
    if not counter:
        return ""
    return counter.most_common(1)[0][0]


def build_possible_concerns(title: str, responsibilities: List[str], evidence: List[Dict[str, Any]], focus_terms: List[str]) -> List[Dict[str, str]]:
    concerns: List[Dict[str, str]] = []
    top_evidence = sorted(evidence, key=lambda item: item.get("source_score", 0), reverse=True)
    evidence_text = " ".join(item.get("content", "") for item in top_evidence[:3])
    if "数字化/信息化" in responsibilities:
        concerns.append(
            {
                "point": "关注平台建设进度、项目成效和跨部门落地。",
                "basis": "公开信息出现数字化/信息化/平台建设相关分工或活动。",
            }
        )
    if "数据治理" in responsibilities:
        concerns.append(
            {
                "point": "关注数据治理、共享协同、分类分级与授权运营。",
                "basis": "公开信息出现数据治理、数据资源或数据安全相关表述。",
            }
        )
    if "网信/网络安全" in responsibilities:
        concerns.append(
            {
                "point": "关注合规整改、风险闭环和重大活动安全保障。",
                "basis": "公开信息出现网信、网络安全、整改或保障相关表述。",
            }
        )
    if "项目建设" in responsibilities and not concerns:
        concerns.append(
            {
                "point": "关注项目进度、预算执行和验收成效。",
                "basis": "公开活动或报道集中在项目建设、推进会、专题会。",
            }
        )
    for focus_term in focus_terms:
        if focus_term and focus_term in evidence_text:
            concerns.insert(
                0,
                {
                    "point": f"可能重点关注与“{focus_term}”相关的建设和交付结果。",
                    "basis": f"搜索结果中该领导与“{focus_term}”共现。",
                }
            )
            break
    if not concerns:
        concerns.append(
            {
                "point": "公开证据不足，暂以岗位职责相关的项目推进和风险控制为主要关注假设。",
                "basis": "当前仅有职务或活动信息，未见更明确分工。",
            }
        )
    return concerns[:2]


def infer_confidence(source_types: Counter, title: str, responsibilities: List[str], sources: List[Dict[str, str]]) -> str:
    official_count = source_types.get("official", 0) + source_types.get("government_public", 0) + source_types.get("enterprise_disclosure", 0)
    professional_count = source_types.get("professional_registry", 0) + source_types.get("registry", 0)
    if official_count >= 2 and title and responsibilities and len(sources) >= 2:
        return "高"
    if official_count >= 1 and title and len(sources) >= 1:
        return "中"
    if professional_count >= 1 and title and len(sources) >= 1:
        return "中"
    return "低"


def summarize_leader_searches(customer_name: str, leader_name: str, query_payloads: List[Dict[str, Any]], focus_terms: List[str]) -> Dict[str, Any]:
    candidates = [fetch_candidate_page(item) for item in select_fetch_candidates(query_payloads, leader_name)]
    customer_aliases = build_customer_aliases(customer_name)
    evidence: List[Dict[str, Any]] = []
    source_types: Counter = Counter()
    responsibility_scores: Counter = Counter()
    dates: Counter = Counter()
    focus_hits: Counter = Counter()
    bio_candidates: List[str] = []
    activity_candidates: List[str] = []
    project_candidates: List[str] = []
    for item in candidates:
        source_type = item.get("source_type", "other")
        source_score = item.get("source_score", 20)
        page_text = clean_evidence_text(item.get("page_text", ""))
        content_text = clean_evidence_text(item.get("content", ""))
        query_id = item.get("query_id", "")
        is_attachment = is_attachment_url(item.get("url", ""))
        scope_text = f"{item.get('title', '')} {content_text} {page_text}"
        customer_specific = contains_customer_alias(scope_text, customer_aliases) or source_type in ("official", "government_public")
        source_types[source_type] += 1
        context_sentences = pick_sentences(page_text, leader_name, tuple(), limit=3)
        if not context_sentences:
            fallback = prefer_sentence(f"{item.get('title', '')} {item.get('content', '')}", leader_name)
            context_sentences = [fallback] if fallback else []
        for context in context_sentences:
            evidence_item = {
                "query_id": item.get("query_id", ""),
                "title": item.get("title", ""),
                "url": item.get("url", ""),
                "content": item.get("content", ""),
                "context": context,
                "source_type": source_type,
                "source_score": source_score,
            }
            evidence.append(evidence_item)
            for date_value in extract_dates(context):
                dates[date_value] += source_score
            for responsibility in infer_responsibilities(context):
                responsibility_scores[responsibility] += source_score
            for focus_term in focus_terms:
                if focus_term and focus_term in context:
                    focus_hits[focus_term] += source_score
        if query_id in ("official_profile", "bio", "bio_general", "appointment", "wiki", "customer_baike", "disclosure_resume", "executive_database", "same_person_check"):
            page_bios = pick_sentences(page_text, leader_name, BIO_HINTS, limit=2)
            content_bios = pick_sentences(content_text, leader_name, BIO_HINTS, limit=1)
            for text in page_bios + content_bios:
                if customer_specific and (not is_attachment or is_good_bio_text(text)) and is_good_bio_text(text):
                    bio_candidates.append(text)
        if query_id in ("activity", "public_statement", "customer_official_news", "focus_1", "focus_2", "official_profile"):
            page_activities = pick_sentences(page_text, leader_name, ACTIVITY_HINTS, limit=2)
            content_activities = pick_sentences(content_text, leader_name, ACTIVITY_HINTS, limit=1)
            for text in page_activities + content_activities:
                if customer_specific and not is_attachment and is_good_activity_text(text, leader_name):
                    activity_candidates.append(text)
        page_projects = pick_sentences(page_text, leader_name, PROJECT_HINTS, limit=2)
        content_projects = pick_sentences(content_text, leader_name, PROJECT_HINTS, limit=1)
        for text in page_projects + content_projects:
            if customer_specific and (not is_attachment or query_id == "official_profile") and is_good_project_text(text):
                project_candidates.append(text)
        if query_id in ("bio", "bio_general", "wiki", "customer_baike", "disclosure_resume", "executive_database", "same_person_check"):
            fallback_bio = prefer_sentence(content_text, leader_name)
            if customer_specific and fallback_bio and is_good_bio_text(fallback_bio):
                bio_candidates.append(fallback_bio)
        if query_id in ("activity", "public_statement", "customer_official_news"):
            fallback_activity = prefer_sentence(content_text, leader_name)
            if customer_specific and fallback_activity and not is_attachment and is_good_activity_text(fallback_activity, leader_name):
                activity_candidates.append(fallback_activity)
    bios = dedupe_texts(bio_candidates, limit=3)
    activities = dedupe_texts(activity_candidates, limit=3)
    project_links = dedupe_texts(project_candidates, limit=3)
    sources = finalize_source_links(customer_name, unique_sources(evidence, limit=6), limit=2, force_required=True)
    responsibilities = [label for label, _score in responsibility_scores.most_common(4)]
    concerns = build_possible_concerns("", responsibilities, evidence, focus_terms)
    return {
        "responsibilities": responsibilities,
        "appointment_time": pick_top_value(dates) or "未公开确认",
        "past_experience": bios,
        "public_activities": activities,
        "project_policy_links": project_links,
        "possible_concerns": concerns,
        "sources": sources,
        "confidence": infer_confidence(source_types, leader_name, responsibilities, sources),
        "focus_matches": list(focus_hits.keys()),
        "ranking_score": sum(focus_hits.values()),
    }


def finalize_leader_record(customer_name: str, raw: Dict[str, Any], focus_terms: List[str]) -> Dict[str, Any]:
    title = pick_top_value(raw["title_scores"])
    responsibilities = [label for label, _score in raw["responsibility_scores"].most_common(4)]
    sources = finalize_source_links(customer_name, unique_sources(raw["evidence"], limit=5), limit=2, force_required=True)
    activities = pick_top_text(raw["activities"], limit=2)
    project_links = pick_top_text(raw["project_policy_links"], limit=2)
    appointment_time = pick_top_value(raw["dates"])
    role_label = infer_role_label(title, responsibilities)
    concerns = build_possible_concerns(title, responsibilities, raw["evidence"], focus_terms)
    confidence = infer_confidence(raw["source_types"], title, responsibilities, sources)
    ranking_score = sum(raw["title_scores"].values())
    if role_label.startswith("一把手"):
        ranking_score += 220
    if any(tag in responsibilities for tag in ("数字化/信息化", "数据治理", "网信/网络安全")):
        ranking_score += 180
    ranking_score += sum(raw["focus_hits"].values())
    return {
        "name": raw["name"],
        "current_title": title,
        "role_label": role_label,
        "responsibilities": responsibilities,
        "appointment_time": appointment_time or "未公开确认",
        "past_experience": pick_top_text(raw["evidence"], limit=2),
        "public_activities": activities,
        "project_policy_links": project_links,
        "possible_concerns": concerns,
        "sources": sources,
        "confidence": confidence,
        "ranking_score": ranking_score,
        "focus_matches": list(raw["focus_hits"].keys()),
    }


def select_leaders(leaders: List[Dict[str, Any]], leader_limit: int) -> List[Dict[str, Any]]:
    bounded_limit = min(max(leader_limit, 1), 20)
    return leaders[:bounded_limit]


def merge_official_and_generic(customer_name: str, official_leaders: List[Dict[str, Any]], generic_leaders: List[Dict[str, Any]], focus_terms: List[str]) -> List[Dict[str, Any]]:
    if get_special_customer_preset(customer_name):
        return sorted(official_leaders, key=lambda item: item.get("ranking_score", 0), reverse=True)
    if not official_leaders:
        return generic_leaders
    generic_by_name = {item["name"]: item for item in generic_leaders}
    merged: List[Dict[str, Any]] = []
    for official in official_leaders:
        generic = generic_by_name.get(official["name"], {})
        responsibilities = official.get("responsibilities") or generic.get("responsibilities") or []
        past_experience = dedupe_texts((official.get("past_experience") or []) + (generic.get("past_experience") or []), limit=3)
        public_activities = dedupe_texts((official.get("public_activities") or []) + (generic.get("public_activities") or []), limit=3)
        project_policy_links = dedupe_texts((official.get("project_policy_links") or []) + (generic.get("project_policy_links") or []), limit=3)
        concern_evidence = []
        if past_experience:
            concern_evidence.extend({"content": item} for item in past_experience)
        if public_activities:
            concern_evidence.extend({"content": item} for item in public_activities)
        if project_policy_links:
            concern_evidence.extend({"content": item} for item in project_policy_links)
        possible_concerns = official.get("possible_concerns") or generic.get("possible_concerns") or build_possible_concerns(
            official["current_title"], responsibilities, concern_evidence, focus_terms
        )
        merged_sources = finalize_source_links(
            customer_name,
            (official.get("sources") or []) + [item for item in generic.get("sources", []) if item not in (official.get("sources") or [])],
            limit=2,
            force_required=True,
        )
        merged.append(
            {
                "name": official["name"],
                "current_title": official["current_title"],
                "role_label": official.get("role_label") or infer_role_label(official["current_title"], responsibilities),
                "responsibilities": responsibilities,
                "appointment_time": official.get("appointment_time") if official.get("appointment_time") and official.get("appointment_time") != "未公开确认" else generic.get("appointment_time", "未公开确认"),
                "past_experience": past_experience,
                "public_activities": public_activities,
                "project_policy_links": project_policy_links,
                "possible_concerns": possible_concerns,
                "sources": merged_sources,
                "confidence": official.get("confidence") or generic.get("confidence") or "中",
                "ranking_score": official.get("ranking_score", 10000)
                + generic.get("ranking_score", 0)
                + (2500 if (official.get("role_label") or infer_role_label(official["current_title"], responsibilities)).startswith("一把手") else 0)
                + (600 if any(tag in responsibilities for tag in ("数字化/信息化", "数据治理", "网信/网络安全")) else 0),
                "focus_matches": list(dict.fromkeys((official.get("focus_matches") or []) + (generic.get("focus_matches") or []))),
            }
        )
    official_names = {item["name"] for item in official_leaders}
    for generic in generic_leaders:
        if generic.get("name") not in official_names:
            merged.append(generic)
    return sorted(merged, key=lambda item: item["ranking_score"], reverse=True)


def enrich_official_leaders(customer_name: str, official_leaders: List[Dict[str, Any]], api_key: str, max_results: int, focus_terms: List[str]) -> List[Dict[str, Any]]:
    if get_special_customer_preset(customer_name):
        return official_leaders
    if not official_leaders or not api_key:
        return official_leaders
    payloads = run_leader_searches(customer_name, [item["name"] for item in official_leaders], api_key, max_results, focus_terms)
    enriched: List[Dict[str, Any]] = []
    for leader in official_leaders:
        extra = summarize_leader_searches(customer_name, leader["name"], payloads.get(leader["name"], []), focus_terms)
        responsibilities = leader.get("responsibilities") or extra.get("responsibilities") or []
        concerns = extra.get("possible_concerns") or build_possible_concerns(leader["current_title"], responsibilities, [], focus_terms)
        sources = finalize_source_links(
            customer_name,
            leader.get("sources", []) + extra.get("sources", []),
            limit=2,
            force_required=True,
        )
        enriched.append(
            {
                **leader,
                "responsibilities": responsibilities,
                "appointment_time": extra.get("appointment_time") if extra.get("appointment_time") and extra.get("appointment_time") != "未公开确认" else leader.get("appointment_time", "未公开确认"),
                "past_experience": dedupe_texts((leader.get("past_experience") or []) + (extra.get("past_experience") or []), limit=3),
                "public_activities": dedupe_texts((leader.get("public_activities") or []) + (extra.get("public_activities") or []), limit=3),
                "project_policy_links": dedupe_texts((leader.get("project_policy_links") or []) + (extra.get("project_policy_links") or []), limit=3),
                "possible_concerns": concerns,
                "sources": sources,
                "confidence": "高" if sources else leader.get("confidence", "中"),
                "ranking_score": leader.get("ranking_score", 10000) + extra.get("ranking_score", 0),
                "focus_matches": extra.get("focus_matches", []),
            }
        )
    return enriched


def enrich_top_profiles(customer_name: str, all_people: List[Dict[str, Any]], api_key: str, max_results: int, focus_terms: List[str], deep_profile_count: int) -> List[Dict[str, Any]]:
    if get_special_customer_preset(customer_name):
        return all_people
    if not all_people or not api_key or deep_profile_count <= 0:
        return all_people
    top_people = all_people[: min(max(deep_profile_count, 1), len(all_people))]
    payloads = run_leader_searches(customer_name, [item["name"] for item in top_people], api_key, max_results, focus_terms)
    enriched_by_name: Dict[str, Dict[str, Any]] = {}
    for leader in top_people:
        extra = summarize_leader_searches(customer_name, leader["name"], payloads.get(leader["name"], []), focus_terms)
        enriched_by_name[leader["name"]] = {
            **leader,
            "responsibilities": leader.get("responsibilities") or extra.get("responsibilities") or [],
            "appointment_time": leader.get("appointment_time") if leader.get("appointment_time") and leader.get("appointment_time") != "未公开确认" else extra.get("appointment_time", "未公开确认"),
            "past_experience": dedupe_texts((leader.get("past_experience") or []) + (extra.get("past_experience") or []), limit=4),
            "public_activities": dedupe_texts((leader.get("public_activities") or []) + (extra.get("public_activities") or []), limit=4),
            "project_policy_links": dedupe_texts((leader.get("project_policy_links") or []) + (extra.get("project_policy_links") or []), limit=4),
            "possible_concerns": leader.get("possible_concerns") or extra.get("possible_concerns") or [],
            "sources": finalize_source_links(customer_name, (leader.get("sources") or []) + (extra.get("sources") or []), limit=3, force_required=True),
            "confidence": "高" if (leader.get("sources") or extra.get("sources")) else leader.get("confidence", "中"),
            "ranking_score": leader.get("ranking_score", 0) + extra.get("ranking_score", 0),
            "focus_matches": list(dict.fromkeys((leader.get("focus_matches") or []) + (extra.get("focus_matches") or []))),
        }
    return [enriched_by_name.get(item.get("name", ""), item) for item in all_people]


def resolve_qcc_cli(cli_name: str) -> str:
    resolved = shutil.which(cli_name)
    if resolved:
        return resolved
    if cli_name and Path(cli_name).exists():
        return cli_name
    return ""


def run_qcc_command(cli_path: str, args: List[str], timeout: int = 45) -> Dict[str, Any]:
    try:
        completed = subprocess.run(
            [cli_path, *args],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="ignore",
            timeout=timeout,
            check=False,
        )
    except Exception as exc:
        return {"ok": False, "command": args, "stdout": "", "stderr": str(exc), "data": None}
    stdout = completed.stdout.strip()
    stderr = completed.stderr.strip()
    return {
        "ok": completed.returncode == 0,
        "command": args,
        "stdout": stdout,
        "stderr": stderr,
        "data": parse_jsonish_output(stdout),
    }


def parse_jsonish_output(text: str) -> Any:
    value = (text or "").strip()
    if not value:
        return None
    try:
        return json.loads(value)
    except json.JSONDecodeError:
        pass
    match = re.search(r"(\{.*\}|\[.*\])", value, flags=re.S)
    if match:
        try:
            return json.loads(match.group(1))
        except json.JSONDecodeError:
            return value
    return value


def collect_qcc_agent_payload(customer_name: str, args: argparse.Namespace) -> Dict[str, Any]:
    if not args.enable_qcc_agent:
        return {"enabled": False, "results": []}
    cli_path = resolve_qcc_cli(args.qcc_cli)
    if not cli_path:
        return {
            "enabled": True,
            "available": False,
            "message": "Qichacha Agent CLI not found; skipped optional enterprise professional source.",
            "results": [],
        }
    results: List[Dict[str, Any]] = []
    if args.qcc_api_key and not args.skip_qcc_init:
        init_result = run_qcc_command(cli_path, ["init", "--authorization", f"Bearer {args.qcc_api_key}"], timeout=30)
        init_result["stdout"] = "[redacted]"
        init_result["stderr"] = "[redacted]" if init_result.get("stderr") else ""
        results.append({"id": "qcc_init", **init_result})
    commands = [
        ("qcc_company_registration", ["company", "get_company_registration_info", customer_name]),
        ("qcc_key_personnel", ["company", "get_key_personnel", customer_name]),
    ]
    for command_id, command_args in commands:
        results.append({"id": command_id, **run_qcc_command(cli_path, command_args)})
    return {"enabled": True, "available": True, "source_url": QCC_TOOL_SOURCE_URL, "results": results}


def walk_values(value: Any) -> Iterable[Any]:
    if isinstance(value, dict):
        yield value
        for child in value.values():
            yield from walk_values(child)
    elif isinstance(value, list):
        for child in value:
            yield from walk_values(child)


def get_first_value(item: Dict[str, Any], keys: Tuple[str, ...]) -> str:
    for key in keys:
        value = item.get(key)
        if isinstance(value, (str, int, float)):
            text = str(value).strip()
            if text:
                return text
    return ""


def looks_like_qcc_person_name(name: str) -> bool:
    return bool(re.fullmatch(r"[\u4e00-\u9fa5]{2,4}", name or "")) and not any(token in name for token in ("公司", "集团", "部门", "机构"))


def extract_qcc_text_leaders(text: str) -> List[Tuple[str, str]]:
    pairs: List[Tuple[str, str]] = []
    if not text:
        return pairs
    title_pattern = "|".join(re.escape(item) for item in sorted(QCC_MANAGER_TITLE_HINTS, key=len, reverse=True))
    for match in re.finditer(rf"(?P<name>[\u4e00-\u9fa5]{{2,4}})\s*[:：,，/\s-]*\s*(?P<title>{title_pattern})", text):
        name = match.group("name").strip()
        title = match.group("title").strip()
        if looks_like_qcc_person_name(name):
            pairs.append((name, title))
    for match in re.finditer(rf"(?P<title>{title_pattern})\s*[:：,，/\s-]*\s*(?P<name>[\u4e00-\u9fa5]{{2,4}})", text):
        name = match.group("name").strip()
        title = match.group("title").strip()
        if looks_like_qcc_person_name(name):
            pairs.append((name, title))
    return pairs


def extract_qcc_leaders(customer_name: str, qcc_payload: Dict[str, Any]) -> List[Dict[str, Any]]:
    leaders: Dict[str, Dict[str, Any]] = {}
    if not qcc_payload.get("enabled"):
        return []
    for result in qcc_payload.get("results", []):
        if result.get("id") == "qcc_init" or not result.get("ok"):
            continue
        pairs: List[Tuple[str, str]] = []
        data = result.get("data")
        for item in walk_values(data):
            if not isinstance(item, dict):
                continue
            name = get_first_value(item, QCC_NAME_KEYS)
            title = get_first_value(item, QCC_TITLE_KEYS)
            if looks_like_qcc_person_name(name) and title:
                pairs.append((name, title))
        if isinstance(data, str):
            pairs.extend(extract_qcc_text_leaders(data))
        pairs.extend(extract_qcc_text_leaders(result.get("stdout", "")))
        for name, title in pairs:
            if not any(hint in title for hint in QCC_MANAGER_TITLE_HINTS):
                continue
            existing = leaders.setdefault(
                name,
                {
                    "name": name,
                    "title_scores": Counter(),
                    "responsibility_scores": Counter(),
                    "dates": Counter(),
                    "source_links": [],
                    "activities": [],
                    "project_policy_links": [],
                    "evidence": [],
                    "focus_hits": Counter(),
                    "source_types": Counter(),
                },
            )
            existing["title_scores"][title] += source_score("professional_registry") + 40
            existing["source_types"]["professional_registry"] += 1
            existing["evidence"].append(
                {
                    "title": "企查查 Agent/MCP 企业主要人员",
                    "url": QCC_TOOL_SOURCE_URL,
                    "content": f"{customer_name} - {name} - {title}",
                    "context": f"企查查 Agent/MCP 返回 {name} 的企业侧职务信息：{title}",
                    "source_type": "professional_registry",
                    "source_score": source_score("professional_registry"),
                }
            )
    finalized: List[Dict[str, Any]] = []
    for raw in leaders.values():
        record = finalize_leader_record(customer_name, raw, [])
        record["confidence"] = "中"
        record["ranking_score"] += 420
        finalized.append(record)
    return sorted(finalized, key=lambda item: item.get("ranking_score", 0), reverse=True)


def merge_professional_registry_leaders(generic_leaders: List[Dict[str, Any]], registry_leaders: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    if not registry_leaders:
        return generic_leaders
    by_name = {item.get("name", ""): dict(item) for item in generic_leaders if item.get("name")}
    for registry in registry_leaders:
        name = registry.get("name", "")
        if not name:
            continue
        if name not in by_name:
            by_name[name] = registry
            continue
        current = by_name[name]
        current["sources"] = finalize_source_links(
            "",
            (current.get("sources") or []) + (registry.get("sources") or []),
            limit=3,
            force_required=True,
        )
        current["past_experience"] = dedupe_texts((current.get("past_experience") or []) + (registry.get("past_experience") or []), limit=3)
        current["public_activities"] = dedupe_texts((current.get("public_activities") or []) + (registry.get("public_activities") or []), limit=3)
        current["project_policy_links"] = dedupe_texts((current.get("project_policy_links") or []) + (registry.get("project_policy_links") or []), limit=3)
        current["ranking_score"] = current.get("ranking_score", 0) + registry.get("ranking_score", 0)
        if current.get("confidence") == "低":
            current["confidence"] = registry.get("confidence", "中")
    return sorted(by_name.values(), key=lambda item: item.get("ranking_score", 0), reverse=True)


def derive_topic_terms(leaders: List[Dict[str, Any]], focus_terms: List[str]) -> List[str]:
    terms: List[str] = []
    for term in focus_terms:
        if term and term not in terms:
            terms.append(term)
    keyword_map = {
        "AI安全": ("AI", "大模型", "智能体", "模型"),
        "数据安全": ("数据", "数据治理", "数据要素", "可信数据空间"),
        "安全运营/MSS": ("安全运营", "MSS", "重保", "响应", "网络韧性"),
        "数字化/信息化": ("数字化", "信息化", "平台", "系统建设"),
        "合规与风险": ("合规", "审计", "整改", "风险", "等保", "密评"),
    }
    merged_text = " ".join(
        " ".join(
            [
                leader.get("current_title", ""),
                " ".join(leader.get("responsibilities", [])),
                " ".join(leader.get("public_activities", [])),
                " ".join(leader.get("project_policy_links", [])),
                " ".join(item.get("point", "") for item in leader.get("possible_concerns", [])),
            ]
        )
        for leader in leaders
    )
    for label, hints in keyword_map.items():
        if any(hint in merged_text for hint in hints) and label not in terms:
            terms.append(label)
    return terms[:6]


def topic_explanation(term: str) -> str:
    explanations = {
        "AI安全": "围绕大模型、智能体、训练数据、提示词、模型输出和AI应用链路的安全治理，重点解决AI被攻击、数据泄露、越权调用和不可控输出问题。",
        "数据安全": "围绕数据采集、存储、流通、使用、共享和销毁全过程的安全治理，重点解决数据资产可用、可控、可审计和合规流通问题。",
        "安全运营/MSS": "把安全能力从一次性建设转为持续运营服务，强调监测、研判、响应、处置、复盘和指标化改进。",
        "数字化/信息化": "围绕业务系统、数据平台和数字基础设施建设，关注项目交付、跨部门协同、数据质量和运营成效。",
        "合规与风险": "围绕等保、密评、数据安全、审计整改和监管要求建立闭环，减少通报、处罚、问责和项目验收风险。",
    }
    return explanations.get(term, "该主题来自客户或领导公开材料，需要结合最新公开报告、标准、白皮书和客户场景进一步解释其业务价值。")


def topic_material_suggestion(term: str) -> str:
    suggestions = {
        "AI安全": "准备AI安全架构图、智能体风险清单、模型应用防护方案、POC评测指标。",
        "数据安全": "准备数据分类分级、数据流通安全、可信数据空间、数据安全运营案例。",
        "安全运营/MSS": "准备MSS运营闭环、重保案例、检测响应指标、降本增效测算。",
        "数字化/信息化": "准备平台建设路径、集成架构、项目里程碑和可量化成效页。",
        "合规与风险": "准备合规差距分析、整改闭环、审计证据链和验收材料清单。",
    }
    return suggestions.get(term, "准备该主题的一页解释、最新趋势摘要、客户场景映射和可落地方案。")


def person_category(title: str, role_label: str) -> str:
    merged = f"{title} {role_label}"
    if any(keyword in merged for keyword in ("法定代表人", "董事长", "总经理", "一把手")):
        return "核心决策层"
    if any(keyword in merged for keyword in ("副总经理", "副董事长", "CTO", "CIO", "总工", "核心技术", "技术中心")):
        return "经营/技术高管"
    if any(keyword in merged for keyword in ("财务", "董秘", "董事会秘书", "内审")):
        return "财务/披露/内控"
    if any(keyword in merged for keyword in ("独立董事", "监事")):
        return "治理/监督"
    if any(keyword in merged for keyword in ("董事", "职工代表董事")):
        return "董事会成员"
    return "关键人员"


def sales_priority(title: str, role_label: str, responsibilities: List[str]) -> str:
    merged = f"{title} {role_label} {' '.join(responsibilities)}"
    if any(keyword in merged for keyword in ("董事长", "总经理", "法定代表人", "CTO", "CIO", "首席", "技术中心", "副总经理")):
        return "高"
    if any(keyword in merged for keyword in ("财务", "董秘", "董事会秘书", "核心技术", "职工代表董事", "董事")):
        return "中"
    if any(keyword in merged for keyword in ("独立董事", "监事", "内审")):
        return "低"
    return "中"


def should_expand_profile(title: str, role_label: str, responsibilities: List[str]) -> str:
    return "是" if sales_priority(title, role_label, responsibilities) in ("高", "中") else "否"


def render_full_people_roster(leaders: List[Dict[str, Any]]) -> List[str]:
    lines = [
        "## 二、全量人员清单",
        "",
        "| 姓名 | 职务 | 人员类型 | 来源 | 售前优先级 | 是否展开画像 | 备注 |",
        "| --- | --- | --- | --- | --- | --- | --- |",
    ]
    if not leaders:
        lines.append("| 未识别 | 未识别 | 未识别 | 未找到可靠来源 | 低 | 否 | 需要手工补证 |")
        lines.append("")
        return lines
    for leader in leaders:
        title = leader.get("current_title", "")
        role_label = leader.get("role_label", "")
        responsibilities = leader.get("responsibilities", [])
        source_types = sorted({item.get("source_type", "") for item in leader.get("sources", []) if item.get("source_type")})
        source_text = "、".join(source_types) or "公开来源"
        priority = sales_priority(title, role_label, responsibilities)
        expand = should_expand_profile(title, role_label, responsibilities)
        note = "重点画像" if expand == "是" and priority == "高" else ("简表保留" if expand == "否" else "补充画像")
        lines.append(
            f"| {leader.get('name', '')} | {title or '未公开确认'} | {person_category(title, role_label)} | {source_text} | {priority} | {expand} | {note} |"
        )
    lines.append("")
    return lines


def render_governance_supplement(leaders: List[Dict[str, Any]]) -> List[str]:
    supplement = [
        leader
        for leader in leaders
        if sales_priority(leader.get("current_title", ""), leader.get("role_label", ""), leader.get("responsibilities", [])) == "低"
        or any(keyword in leader.get("current_title", "") for keyword in ("独立董事", "监事", "内审", "职工代表董事"))
    ]
    lines = [
        "## 四、治理/监督补充人员",
        "",
        "| 姓名 | 职务 | 为什么保留 | 售前处理建议 |",
        "| --- | --- | --- | --- |",
    ]
    if not supplement:
        lines.append("| 暂无 | 暂无 | 当前人员均已在重点画像中覆盖 | 无 |")
        lines.append("")
        return lines
    for leader in supplement:
        title = leader.get("current_title", "")
        reason = "涉及公司治理、监督、内控、披露或员工代表视角。"
        suggestion = "通常不作为第一汇报对象；涉及合规、审计、披露、治理或员工侧落地时再重点关注。"
        lines.append(f"| {leader.get('name', '')} | {title or '未公开确认'} | {reason} | {suggestion} |")
    lines.append("")
    return lines


def render_business_pressure_bindings(summary: Dict[str, Any], leaders: List[Dict[str, Any]]) -> List[str]:
    top_priority = summary.get("top_priority", {})
    project_owner = summary.get("project_owner", {})
    security_owner = summary.get("security_owner", {})
    finance_owner = next(
        (item for item in leaders if any(keyword in item.get("current_title", "") for keyword in ("财务", "总会计师", "财务总监", "CFO"))),
        {},
    )
    bindings = [
        ("战略增长/政策任务/资本市场预期", top_priority, "关注战略叙事、重大项目、生态影响和标杆价值。", "战略图、行业趋势页、标杆案例。"),
        ("项目交付/业务增长/客户留存", project_owner, "关注交付周期、可复制方案、客户满意度和建设成效。", "项目路线图、交付计划、成功案例。"),
        ("合规风险/安全事件/审计整改", security_owner, "关注风险闭环、检测响应、问责压力和运营指标。", "风险清单、运营闭环、合规证据材料。"),
    ]
    if finance_owner:
        bindings.append(("预算/费用率/现金流/ROI", finance_owner, "关注投入产出、回款、费用控制和财务可解释性。", "ROI测算、成本收益页、付款与回款计划。"))
    lines = [
        "## 三、经营压力/预算压力与高层关注点绑定",
        "",
        "| 压力信号 | 对应高层 | 关注点推断 | 售前材料建议 |",
        "| --- | --- | --- | --- |",
    ]
    seen_rows = set()
    for pressure, leader, concern, material in bindings:
        if not leader:
            continue
        key = (pressure, leader.get("name", ""))
        if key in seen_rows:
            continue
        seen_rows.add(key)
        lines.append(
            f"| {pressure} | {leader.get('name', '待确认')} / {leader.get('current_title', '待确认')} | {concern} | {material} |"
        )
    lines.extend(
        [
            "",
            "> 注：本节为自动绑定的初稿，正式交付时必须用年报、预算、审计、招采、业绩说明会或公开讲话补证压力信号。",
            "",
        ]
    )
    return lines


def render_topic_trend_cards(summary: Dict[str, Any], leaders: List[Dict[str, Any]]) -> List[str]:
    focus_terms = summary.get("focus_terms", [])
    terms = derive_topic_terms(leaders, focus_terms)
    lines = [
        "## 四、近期公开观点主题词与最新技术发展",
        "",
    ]
    if not terms:
        lines.extend(
            [
                "- 当前公开材料未形成稳定主题词。建议补搜客户官网新闻、领导讲话、业绩说明会和行业报告后再生成主题词卡片。",
                "",
            ]
        )
        return lines
    for term in terms:
        related = []
        for leader in leaders:
            haystack = " ".join(
                [
                    leader.get("current_title", ""),
                    " ".join(leader.get("responsibilities", [])),
                    " ".join(leader.get("public_activities", [])),
                    " ".join(leader.get("project_policy_links", [])),
                    " ".join(item.get("point", "") for item in leader.get("possible_concerns", [])),
                ]
            )
            if term in haystack or any(token in haystack for token in term.replace("/", " ").split()):
                related.append(f"{leader.get('name', '')}/{leader.get('current_title', '')}")
        related_text = "；".join(related[:3]) or "待结合公开发言确认"
        lines.extend(
            [
                f"### {term}",
                f"- **关联领导**：{related_text}",
                f"- **售前解释**：{topic_explanation(term)}",
                "- **最新技术发展**：需联网检索近12-18个月白皮书、标准、行业报告和厂商实践后补充，避免只凭历史知识判断。",
                f"- **可切入方案/材料**：{topic_material_suggestion(term)}",
                "- **仍需补证**：对应领导的原始公开发言链接、客户侧项目或经营压力证据。",
                "",
            ]
        )
    return lines


def overall_summary(customer_name: str, leaders: List[Dict[str, Any]], focus_terms: List[str]) -> Dict[str, Any]:
    top_leader = next((item for item in leaders if item.get("role_label", "").startswith("一把手")), leaders[0] if leaders else {})
    project_leader = next((item for item in leaders if "项目建设" in item.get("responsibilities", [])), top_leader)
    security_leader = next((item for item in leaders if "网信/网络安全" in item.get("responsibilities", [])), None)
    if security_leader is None:
        security_leader = next((item for item in leaders if "数据治理" in item.get("responsibilities", [])), None)
    if security_leader is None:
        security_leader = next((item for item in leaders if "数字化/信息化" in item.get("responsibilities", [])), top_leader)
    all_confidences = [item.get("confidence", "低") for item in leaders]
    overall_confidence = "低"
    if leaders:
        if all(level == "高" for level in all_confidences[: min(3, len(all_confidences))]):
            overall_confidence = "高"
        elif any(level in ("高", "中") for level in all_confidences):
            overall_confidence = "中"
    return {
        "customer_name": customer_name,
        "focus_terms": focus_terms,
        "top_priority": top_leader,
        "project_owner": project_leader,
        "security_owner": security_leader,
        "overall_confidence": overall_confidence,
    }


def render_detailed_markdown(
    customer_name: str,
    generated_at: str,
    summary: Dict[str, Any],
    leaders: List[Dict[str, Any]],
    all_people: Optional[List[Dict[str, Any]]] = None,
) -> str:
    all_people = all_people or leaders
    top_priority = summary.get("top_priority", {})
    project_owner = summary.get("project_owner", {})
    security_owner = summary.get("security_owner", {})
    lines = [
        f"# {customer_name} 高层领导情报材料",
        f"> 生成时间：{generated_at}",
        "> 客户类型：政府 / 国企 / 事业单位",
        f"> 输出范围：全量人员清单 {len(all_people)} 位；重点画像 {len(leaders)} 位",
        "",
        "## 一、总体判断",
        f"- **汇报优先对象**：{top_priority.get('name', '未识别')} / {top_priority.get('current_title', '未识别')}",
        f"- **项目关键影响人**：{project_owner.get('name', '未识别')} / {project_owner.get('current_title', '未识别')}",
        f"- **数字化/信息化/安全相关领导**：{security_owner.get('name', '未识别')} / {security_owner.get('current_title', '未识别')}",
        f"- **当前信息可信度**：{summary.get('overall_confidence', '低')}",
        "- **说明**：对“可能关注点”均基于公开信息推断。",
        "",
    ]
    lines.extend(render_full_people_roster(all_people))
    lines.extend(["## 三、重点领导画像", ""])
    for index, leader in enumerate(leaders, start=1):
        bio_summary = build_bio_summary(leader["name"], leader.get("past_experience", []), leader.get("sources", []))
        activity_summary = build_activity_summary(leader["name"], leader.get("public_activities", []), leader.get("possible_concerns", []))
        project_summary = build_project_policy_summary(
            leader.get("project_policy_links", []),
            leader.get("responsibilities", []),
            leader.get("possible_concerns", []),
        )
        lines.extend(
            [
                f"### {index}. {leader['name']}",
                f"- **职位**：{leader['current_title']}",
                *([f"- **办公电话**：{leader['office_phone']}"] if leader.get("office_phone") else []),
                f"- **角色定位**：{leader['role_label']}",
                f"- **分管领域**：{'、'.join(leader['responsibilities']) or '未公开确认'}",
                *([f"- **职责分工**：{leader['duty_text']}"] if leader.get("duty_text") else []),
                f"- **任职时间**：{leader['appointment_time']}",
                f"- **个人情况补充**：{bio_summary}",
                f"- **同名校验**：{('已通过姓名与客户/现任职务来源交叉校验' if leader.get('sources') else '待补充可核验来源；百科类材料未单独采用')}",
                f"- **过往履历**：{bio_summary}",
                f"- **近期公开讲话/活动**：{activity_summary}",
                f"- **项目/政策关联**：{project_summary}",
                f"- **可能关注点（推断）**：{'；'.join(item['point'] for item in leader['possible_concerns'])}",
                f"- **推断依据**：{'；'.join(item['basis'] for item in leader['possible_concerns'])}",
                f"- **信息可信度**：{leader['confidence']}",
                "- **信息来源**：",
            ]
        )
        if leader["sources"]:
            for source in leader["sources"]:
                label = source.get("title") or source.get("url") or "未命名来源"
                lines.append(f"  - {label}：{source.get('url', '')}")
        else:
            lines.append("  - 未找到可靠来源")
        lines.append("")
    lines.extend(render_governance_supplement(all_people))
    lines.extend(render_business_pressure_bindings(summary, leaders))
    lines.extend(render_topic_trend_cards(summary, leaders))
    lines.extend(
        [
            "## 五、汇报建议",
            f"- **建议先汇报给谁**：{top_priority.get('name', '未识别')} / {top_priority.get('current_title', '未识别')}",
            "- **建议强调的项目价值**：围绕其分管领域强调经营压力、建设进度、合规风险控制、跨部门协同和可见成效。",
            "- **建议避免的表述**：避免把推断写成确定事实；避免无证据地判断其分工、偏好或经营压力。",
            "- **需要继续补证的空白点**：任职时间、明确分工、经营/预算压力来源、与当前项目直接相关的公开活动、主题词最新技术发展来源。",
        ]
    )
    return "\n".join(lines)


def render_chat_summary(
    customer_name: str,
    summary: Dict[str, Any],
    leaders: List[Dict[str, Any]],
    all_people: Optional[List[Dict[str, Any]]] = None,
) -> str:
    all_people = all_people or leaders
    top_priority = summary.get("top_priority", {})
    project_owner = summary.get("project_owner", {})
    security_owner = summary.get("security_owner", {})
    lines = [
        f"{customer_name} 关键领导速览",
        "",
        "总体判断",
        f"- 最值得优先关注的是：{top_priority.get('name', '未识别')} / {top_priority.get('current_title', '未识别')}，原因：优先级最高且公开证据最集中。",
        f"- 对项目方向影响最大的是：{project_owner.get('name', '未识别')} / {project_owner.get('current_title', '未识别')}，原因：与项目建设或推进类活动关联度最高。",
        f"- 对合规/安全最敏感的可能是：{security_owner.get('name', '未识别')} / {security_owner.get('current_title', '未识别')}，依据：其公开信息与数据治理、网信或安全关键词关联更强。",
        f"- 当前公开信息完整度：{summary.get('overall_confidence', '低')}",
        "",
        "领导摘要",
    ]
    for leader in leaders[: min(12, len(leaders))]:
        concerns = "；".join(item["point"] for item in leader["possible_concerns"][:1]) or "待补证"
        judgment = f"{leader['role_label']}，分管领域：{'、'.join(leader['responsibilities'][:2]) or '未公开确认'}"
        lines.append(f"- {leader['name']}｜{leader['current_title']}：{judgment}；关注点：{concerns}")
    low_priority = [
        f"{leader.get('name', '')}/{leader.get('current_title', '')}"
        for leader in all_people
        if sales_priority(leader.get("current_title", ""), leader.get("role_label", ""), leader.get("responsibilities", [])) == "低"
    ]
    topic_terms = derive_topic_terms(leaders, summary.get("focus_terms", []))
    lines.extend(
        [
            "",
            "全量人员覆盖",
            f"- 已确认人员：{len(all_people)} 位；摘要展示重点画像 {min(12, len(leaders))} 位，详细版保留完整人员清单。",
            f"- 治理/监督补充：{'；'.join(low_priority) if low_priority else '暂无低优先级治理人员单列'}。",
            "",
            "经营压力绑定",
            f"- 战略增长/政策任务 -> {top_priority.get('name', '未识别')} / {top_priority.get('current_title', '未识别')}：建议准备战略图、行业趋势页、标杆案例。",
            f"- 项目交付/业务增长 -> {project_owner.get('name', '未识别')} / {project_owner.get('current_title', '未识别')}：建议准备项目路线图、交付计划、成功案例。",
            f"- 合规风险/安全事件 -> {security_owner.get('name', '未识别')} / {security_owner.get('current_title', '未识别')}：建议准备风险清单、运营闭环、合规证据材料。",
            "",
            "主题词与技术发展",
            *[
                f"- {term}：解释：{topic_explanation(term)}；最新发展需联网核验；建议材料：{topic_material_suggestion(term)}"
                for term in topic_terms[:4]
            ],
            "",
            "风险提示",
            "- 姓名、职位、来源链接优先来自官方页面、政府公开文件和新闻稿。",
            "- “可能关注点”属于基于公开信息的推断，不能替代正式组织分工。",
            "- 经营压力和技术趋势必须继续补证年报、预算、审计、招采、业绩说明会、白皮书或权威报告。",
        ]
    )
    return "\n".join(lines)


def ensure_stdout_utf8() -> None:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="ignore")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8", errors="ignore")


def main() -> int:
    ensure_stdout_utf8()
    args = build_parser().parse_args()
    focus_terms = split_focus_terms(args.focus)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    preset_customer = bool(get_special_customer_preset(args.customer_name))

    if args.search_payload:
        search_payload = load_search_payload(Path(args.search_payload))
    elif preset_customer:
        search_payload = {"queries": []}
    else:
        if not args.tavily_api_key:
            if not args.enable_qcc_agent:
                print("未提供 Tavily API Key，且未指定 --search-payload。", file=sys.stderr)
                return 1
            search_payload = {"queries": []}
        else:
            search_payload = run_searches(args.customer_name, args.tavily_api_key, args.max_results, focus_terms)

    if args.save_search_payload:
        save_search_payload(Path(args.save_search_payload), search_payload)

    generated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    generic_leaders = extract_leaders(args.customer_name, search_payload, focus_terms)
    qcc_payload = collect_qcc_agent_payload(args.customer_name, args)
    qcc_leaders = extract_qcc_leaders(args.customer_name, qcc_payload)
    generic_leaders = merge_professional_registry_leaders(generic_leaders, qcc_leaders)
    seed_urls = build_seed_urls(args.customer_name, args.official_roster_url)
    official_leaders = extract_official_roster(args.customer_name, search_payload, seed_urls=seed_urls)
    official_leaders = enrich_official_leaders(args.customer_name, official_leaders, args.tavily_api_key, args.max_results, focus_terms)
    all_people = merge_official_and_generic(args.customer_name, official_leaders, generic_leaders, focus_terms)
    all_people = enrich_top_profiles(args.customer_name, all_people, args.tavily_api_key, args.max_results, focus_terms, args.deep_profile_count)
    leaders = select_leaders(all_people, args.leader_limit)
    summary = overall_summary(args.customer_name, leaders, focus_terms)

    detail_md = render_detailed_markdown(args.customer_name, generated_at, summary, leaders, all_people=all_people)
    chat_txt = render_chat_summary(args.customer_name, summary, leaders, all_people=all_people)

    safe_name = sanitize_filename(args.customer_name)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    detail_path = output_dir / f"{safe_name}_领导情报_{timestamp}.md"
    chat_path = output_dir / f"{safe_name}_领导摘要_{timestamp}.txt"

    detail_path.write_text(detail_md, encoding="utf-8")
    chat_path.write_text(chat_txt, encoding="utf-8")

    print(detail_path)
    print(chat_path)
    if leaders:
        top = leaders[0]
        print(f"Top Leader: {top['name']} / {top['current_title']}")
    else:
        print("Top Leader: 未识别")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
