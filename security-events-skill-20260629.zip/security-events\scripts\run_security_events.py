from __future__ import annotations

import argparse
import json
import os
import re
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import requests


REPO_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_OUTPUT_DIR = REPO_ROOT / "output" / "security-events"
DEFAULT_TAVILY_URL = "https://api.tavily.com/search"
DEFAULT_TAVILY_API_KEY = "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"
DEFAULT_MAX_RESULTS = 5
MAX_EVENT_AGE_DAYS = 400

REALIZED_IMPACT_TERMS = (
    "泄露",
    "被盗",
    "盗刷",
    "停摆",
    "中断",
    "勒索",
    "删除",
    "接管",
    "诈骗",
    "入侵",
    "窃取",
    "越权",
    "误删",
    "失控",
    "损失",
    "感染",
    "被控",
    "deleted",
    "deleting",
    "wiped",
    "data loss",
    "lost data",
    "leaked",
    "breach",
    "stolen",
    "infected",
    "compromised",
    "taken over",
    "ignored commands",
    "ran amok",
    "went rogue",
    "loses control",
    "lost control",
    "loss of control",
    "outage",
    "disrupted",
    "unauthorized action",
)
OBSERVED_ATTACK_TERMS = (
    "恶意插件",
    "恶意skill",
    "恶意 skill",
    "假冒安装包",
    "投递木马",
    "攻击活动",
    "攻击链",
    "malicious skill",
    "fake installer",
    "infostealer",
    "information stealer",
    "delivered malware",
    "attack campaign",
)
RESPONSE_TERMS = (
    "处罚",
    "整改",
    "通报",
)
WARNING_ONLY_TERMS = (
    "预警",
    "风险提示",
    "安全建议",
    "实践指南",
    "advisory",
    "warning",
    "guidance",
    "best practice",
)
IMPACT_TERMS = REALIZED_IMPACT_TERMS + OBSERVED_ATTACK_TERMS + RESPONSE_TERMS
LOW_SIGNAL_TERMS = ("漏洞", "预警", "补丁", "修复", "更新", "公告", "vulnerability", "advisory", "warning", "patch")
NAVIGATION_TERMS = (
    "登录",
    "注册",
    "产品",
    "资源",
    "下载地址",
    "全文链接",
    "预约演示",
    "博客",
    "解决方案",
    "白皮书",
    "定价",
)
LISTING_TERMS = (
    "当前位置",
    "返回顶部",
    "上一篇",
    "下一篇",
    "更多>>",
    "Produced By CMS",
    "工作动态",
    "最新资讯",
    "政务要闻",
    "网站首页",
)
REPORT_TERMS = (
    "月报",
    "周报",
    "季报",
    "年度报告",
    "年度回顾",
    "回顾",
    "展望",
    "态势报告",
    "全球",
    "百科",
    "法规",
    "条例",
    "管理办法",
    "征求意见",
    "范式",
    "解读",
    "指南",
    "清单",
    "工作报告",
)
REGULATION_TERMS = (
    "网络安全法",
    "数据安全法",
    "个人信息保护法",
    "条例",
    "办法",
    "规定",
    "法条",
    "附则",
    "监督管理",
)
EVENT_TERMS = IMPACT_TERMS + WARNING_ONLY_TERMS + (
    "辟谣",
    "典型案例",
    "未授权访问",
    "被攻击",
    "incident",
    "security incident",
    "cyberattack",
)
GOV_SERVICE_TERMS = ("政务", "公共服务", "个人信息", "档案", "查询", "短信", "诈骗", "app")
AI_AGENT_TERMS = ("openclaw", "龙虾", "智能体", "提示词注入", "插件投毒", "高权限执行")

OFFICIAL_DOMAINS = (
    "gov.cn",
    "mohrss.gov.cn",
    "cac.gov.cn",
    "miit.gov.cn",
    "mps.gov.cn",
    "news.cn",
    "cncert.cn",
    "cert.org",
    "hkcert.org",
    "oecd.ai",
)
MAINSTREAM_DOMAINS = (
    "xinhuanet.com",
    "cnr.cn",
    "cctv.com",
    "people.com.cn",
    "china.com.cn",
    "reuters.com",
    "apnews.com",
    "bbc.com",
    "techcrunch.com",
    "wired.com",
    "theregister.com",
    "arstechnica.com",
    "indianexpress.com",
    "timesofindia.indiatimes.com",
    "tomshardware.com",
    "windowscentral.com",
)
OFFICIAL_QUERY_DOMAINS = [
    "gov.cn",
    "mohrss.gov.cn",
    "cac.gov.cn",
    "miit.gov.cn",
    "mps.gov.cn",
    "news.cn",
]
BLOCKED_DOMAINS = (
    "wikipedia.org",
    "cyberhoot.com",
    "dwcon.cn",
    "deheheng.com",
    "chinalawtranslate.com",
    "zhihu.com",
    "csdn.net",
    "sohu.com",
    "163.com",
)
BLOCKED_URL_PATTERNS = (
    "/developer/article/",
    "baijiahao.baidu.com",
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Collect recent security events for a customer topic or industry.")
    parser.add_argument("customer_name", help="Customer name")
    parser.add_argument("--industry", default="", help="Industry hint")
    parser.add_argument("--topic", default="", help="Product or topic hint")
    parser.add_argument("--scenario", default="", help="Scenario hint")
    parser.add_argument("--risk-tags", default="", help="Comma-separated risk tags")
    parser.add_argument("--source-intel-json", default="", help="Optional customer-intel JSON path")
    parser.add_argument("--search-payload", default="", help="Offline search payload JSON")
    parser.add_argument("--save-search-payload", default="", help="Save live search payload JSON")
    parser.add_argument("--output-dir", default=str(DEFAULT_OUTPUT_DIR), help="Output directory")
    parser.add_argument("--max-results", type=int, default=DEFAULT_MAX_RESULTS, help="Max results per query")
    parser.add_argument(
        "--tavily-api-key",
        default=os.environ.get("TAVILY_API_KEY") or DEFAULT_TAVILY_API_KEY,
        help="Tavily API key",
    )
    return parser


def split_csv(text: str) -> list[str]:
    return [item.strip() for item in re.split(r"[,，;；、]", text or "") if item.strip()]


def safe_name(text: str) -> str:
    return re.sub(r'[<>:"/\\|?*]+', "_", text).strip() or "security_events"


def load_json(path: str | Path | None) -> dict[str, Any]:
    if not path:
        return {}
    target = Path(path)
    if not target.exists():
        return {}
    return json.loads(target.read_text(encoding="utf-8-sig"))


def load_text(path: str | Path) -> str:
    return Path(path).read_text(encoding="utf-8-sig")


def enrich_context(args: argparse.Namespace) -> tuple[str, str]:
    industry = args.industry.strip()
    customer_name = args.customer_name.strip()
    intel_payload = load_json(args.source_intel_json)
    if intel_payload:
        customer_name = intel_payload.get("customer_name", customer_name) or customer_name
        company_basics = intel_payload.get("company_basics", {})
        if not industry:
            industry = (
                company_basics.get("customer_industry")
                or company_basics.get("industry_track")
                or intel_payload.get("industry", "")
            )
    return customer_name, industry.strip()


def is_public_service_customer(industry: str, customer_name: str) -> bool:
    joined = f"{industry} {customer_name}"
    return any(term in joined for term in ("政府", "政务", "公共服务", "事业单位", "厅", "局", "中心"))


def primary_topic_seed(topic: str) -> str:
    if "openclaw" in topic.lower():
        return "OpenClaw"
    parts = split_csv(topic)
    return parts[0] if parts else topic.strip()


def build_queries(
    customer_name: str,
    topic: str,
    industry: str,
    scenario: str,
    risk_tags: list[str],
) -> list[dict[str, str]]:
    year = datetime.now().year
    topic_seed = primary_topic_seed(topic)
    queries: list[dict[str, str]] = []

    def add_query(query_id: str, query_text: str, include_domains: list[str] | None = None) -> None:
        item: dict[str, Any] = {"id": query_id, "query": query_text}
        if include_domains:
            item["include_domains"] = include_domains
        queries.append(item)

    if customer_name:
        add_query("customer_direct_incident_zh", f"{customer_name} 数据泄露 网络攻击 业务中断 真实事件 {year}")
        add_query("customer_direct_incident_en", f'"{customer_name}" cyber incident data breach outage {year}')

    if topic_seed:
        add_query("topic_real_incident_zh", f"{topic_seed} 真实事故 数据删除 失控 数据泄露 业务影响 {year}")
        add_query(
            "topic_real_incident_en",
            f'"{topic_seed}" incident deleted emails data loss ignored commands went rogue {year}',
        )
        add_query(
            "topic_attack_campaign_en",
            f'"{topic_seed}" malicious skills fake installer malware victims attack campaign {year}',
        )
        for index, risk in enumerate(risk_tags[:2], start=1):
            add_query(f"topic_risk_{index}", f"{topic_seed} {risk} 事故 案例 {year}")
        add_query("topic_authoritative_context", f"{topic_seed} 风险预警 安全指南 {year}", OFFICIAL_QUERY_DOMAINS)

    if topic_seed and industry:
        add_query("topic_industry", f"{topic_seed} {industry} 事故 数据丢失 生产中断 {year}")

    if industry:
        add_query("industry_recent", f"{industry} 网络安全 真实事件 业务中断 数据泄露 {year}")
        if topic_seed:
            add_query("industry_analogue_en", f'AI agent incident manufacturing deleted data outage "{topic_seed}" {year}')

    if is_public_service_customer(industry, customer_name):
        add_query("public_service_fraud", f"公共服务 补贴 诈骗 辟谣 官方 {year}", OFFICIAL_QUERY_DOMAINS)
        add_query("notice_spoofing", f"政务服务 短信 诈骗 辟谣 官方 {year}", OFFICIAL_QUERY_DOMAINS)
        add_query("gov_service_attack", f"政务服务系统 攻击 诈骗 通报 {year}", OFFICIAL_QUERY_DOMAINS)
        add_query("gov_interface_breach", f"档案 查询 接口 未授权访问 个人信息 通报 {year}", OFFICIAL_QUERY_DOMAINS)
        add_query("pii_enforcement", f"网信办 个人信息保护 典型案例 {year}", OFFICIAL_QUERY_DOMAINS)
        add_query("data_security_enforcement", f"数据安全 执法 典型案例 政务 {year}", OFFICIAL_QUERY_DOMAINS)
    if scenario:
        add_query("scenario_recent", f"{scenario} 真实事故 业务影响 案例 {year}")

    deduped: list[dict[str, str]] = []
    seen: set[str] = set()
    for item in queries:
        key = f"{item['query']}|{','.join(item.get('include_domains', []))}"
        if key in seen:
            continue
        seen.add(key)
        deduped.append(item)
    return deduped


def search_tavily(api_key: str, query: str, max_results: int, include_domains: list[str] | None = None) -> dict[str, Any]:
    payload = {
        "query": query,
        "topic": "general",
        "search_depth": "advanced",
        "max_results": max_results,
    }
    if include_domains:
        payload["include_domains"] = include_domains
    for attempt in range(2):
        response = requests.post(
            DEFAULT_TAVILY_URL,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            json=payload,
            timeout=60,
        )
        if response.ok:
            return response.json()
        if response.status_code in (429, 432) and attempt == 0:
            time.sleep(2)
            continue
        if response.status_code in (429, 432):
            return {"results": []}
        response.raise_for_status()
    return {"results": []}


def collect_live_payload(queries: list[dict[str, str]], api_key: str, max_results: int) -> dict[str, Any]:
    payload: dict[str, Any] = {"queries": []}
    for query_item in queries:
        include_domains = query_item.get("include_domains")
        result = search_tavily(api_key, query_item["query"], max_results, include_domains)
        payload["queries"].append(
            {
                "id": query_item["id"],
                "query": query_item["query"],
                "include_domains": include_domains or [],
                "results": result.get("results", []),
            }
        )
    return payload


def normalize_title(title: str) -> str:
    return re.sub(r"\s+", "", title or "").strip().lower()


def extract_domain(url: str) -> str:
    host = urlparse(url).netloc.lower()
    return host[4:] if host.startswith("www.") else host


def source_bucket(url: str) -> str:
    domain = extract_domain(url)
    if any(domain.endswith(item) for item in BLOCKED_DOMAINS):
        return "blocked"
    if any(pattern in url for pattern in BLOCKED_URL_PATTERNS):
        return "blocked"
    if any(domain.endswith(item) for item in OFFICIAL_DOMAINS):
        return "official"
    if any(domain.endswith(item) for item in MAINSTREAM_DOMAINS):
        return "mainstream"
    return "other"


def parse_date(date_text: str) -> datetime | None:
    if not date_text:
        return None
    text = date_text.strip()
    for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%dT%H:%M:%S.%fZ"):
        try:
            return datetime.strptime(text[: len(fmt)], fmt)
        except ValueError:
            continue
    match = re.search(r"(20\d{2})[-/年](\d{1,2})[-/月](\d{1,2})", text)
    if match:
        year, month, day = map(int, match.groups())
        try:
            return datetime(year, month, day)
        except ValueError:
            return None
    return None


def infer_date(text: str, url: str) -> datetime | None:
    for candidate in (text, url):
        parsed = parse_date(candidate)
        if parsed:
            return parsed
        compact = re.search(r"(20\d{2})(\d{2})(\d{2})", candidate)
        if compact:
            year, month, day = map(int, compact.groups())
            try:
                return datetime(year, month, day)
            except ValueError:
                continue
    return None


def is_recent_enough(date_text: str, title: str, url: str) -> bool:
    parsed = infer_date(date_text or title, url)
    if not parsed:
        return True
    return parsed >= datetime.now() - timedelta(days=MAX_EVENT_AGE_DAYS)


def is_low_signal(text: str) -> bool:
    lowered = text.lower()
    return any(term in lowered for term in LOW_SIGNAL_TERMS) and not any(term in lowered for term in REALIZED_IMPACT_TERMS + OBSERVED_ATTACK_TERMS)


def looks_like_navigation(title: str, content: str) -> bool:
    text = f"{title} {content}"
    if any(term in text for term in NAVIGATION_TERMS):
        return True
    if len(content) > 1200 and not any(term in text for term in IMPACT_TERMS):
        return True
    return False


def looks_like_listing_page(title: str, content: str) -> bool:
    text = f"{title} {content}"
    if any(term in text for term in LISTING_TERMS):
        return True
    if content.count("./20") >= 3:
        return True
    if len(re.findall(r"20\d{2}[-/年]\d{1,2}", content)) >= 6 and any(term in content for term in ("首页", "当前位置", "发布", "栏目")):
        return True
    return False


def looks_like_report_or_rule(title: str, content: str) -> bool:
    text = f"{title} {content}"
    return any(term in text for term in REPORT_TERMS) and not any(term in text for term in IMPACT_TERMS)


def looks_like_regulation_page(title: str, content: str) -> bool:
    text = f"{title} {content}"
    if not any(term in text for term in EVENT_TERMS):
        return any(term in text for term in REGULATION_TERMS)
    return False


def title_is_non_event(title: str) -> bool:
    return any(term in title for term in REPORT_TERMS)


def has_event_signal(title: str, content: str) -> bool:
    text = f"{title} {content}".lower()
    return any(term in text for term in EVENT_TERMS)


def classify_event_type(title: str, content: str) -> str:
    lowered_title = title.lower()
    text = f"{title} {content}".lower()
    if any(term in lowered_title for term in WARNING_ONLY_TERMS + ("涨知识", "安全风险", "须防", "风险分析")):
        return "warning_or_guidance"
    if any(term in lowered_title for term in REALIZED_IMPACT_TERMS):
        return "realized_incident"
    if any(term in lowered_title for term in OBSERVED_ATTACK_TERMS):
        return "observed_attack"
    if any(term in lowered_title for term in ("监测", "测绘", "暴露", "exposed", "scan", "researchers found")):
        return "measured_exposure"
    if any(term in text for term in REALIZED_IMPACT_TERMS):
        return "realized_incident"
    if any(term in text for term in OBSERVED_ATTACK_TERMS):
        return "observed_attack"
    if any(term in text for term in ("监测", "测绘", "暴露", "exposed", "scan", "researchers found")):
        return "measured_exposure"
    if any(term in text for term in WARNING_ONLY_TERMS):
        return "warning_or_guidance"
    return "unclassified"


def has_sector_signal(text: str, industry: str, customer_name: str) -> bool:
    merged = f"{text} {industry} {customer_name}".lower()
    return any(term.lower() in merged for term in GOV_SERVICE_TERMS)


def is_irrelevant_agent_topic(topic: str, title: str, content: str) -> bool:
    if not topic:
        return False
    lowered_topic = topic.lower()
    if any(term in lowered_topic for term in ("openclaw", "龙虾", "智能体", "agent", "ai")):
        return False
    lowered_text = f"{title} {content}".lower()
    return any(term in lowered_text for term in AI_AGENT_TERMS)


def build_relevance_reason(topic: str, industry: str, risk_tags: list[str], text: str) -> str:
    reasons: list[str] = []
    lowered = text.lower()
    if topic and topic.lower() in lowered:
        reasons.append(f"直接关联主题 {topic}")
    if industry and industry.lower() in lowered:
        reasons.append(f"涉及行业 {industry}")
    matched_risks = [risk for risk in risk_tags if risk and risk.lower() in lowered]
    if matched_risks:
        reasons.append(f"命中风险词 {matched_risks[0]}")
    if not reasons:
        reasons.append("与当前交流场景相关")
    return "，".join(reasons[:2])


def score_event(topic: str, industry: str, risk_tags: list[str], title: str, content: str, query: str, url: str, date_text: str) -> int:
    text = " ".join([title, content, url]).lower()
    lowered_title = title.lower()
    score = 0
    topic_seed = primary_topic_seed(topic).lower()
    if topic_seed and topic_seed in text:
        score += 45
    if industry and industry.lower() in text:
        score += 20
    for risk in risk_tags:
        if risk and risk.lower() in text:
            score += 10
    for impact in REALIZED_IMPACT_TERMS:
        if impact in text:
            score += 8

    event_type = classify_event_type(title, content)
    if event_type == "realized_incident":
        score += 70
    elif event_type == "observed_attack":
        score += 50
    elif event_type == "measured_exposure":
        score += 15
    elif event_type == "warning_or_guidance":
        score -= 30

    if any(term in lowered_title for term in REALIZED_IMPACT_TERMS):
        score += 55
    if any(term in lowered_title for term in ("高管", "负责人", "研究员", "员工", "公司", "工厂", "director", "researcher", "employee", "company", "factory")):
        score += 12
    if any(term in lowered_title for term in ("涨知识", "拆解", "盘点", "趋势", "指南", "解读", "如何", "explained", "overview")):
        score -= 35

    bucket = source_bucket(url)
    if bucket == "official":
        score += 25
    elif bucket == "mainstream":
        score += 25
    elif bucket == "blocked":
        score -= 100
    else:
        score += 0

    if any(term in text for term in ("案例", "incident", "case", "victim", "受害", "损失")):
        score += 12
    if not is_recent_enough(date_text, title, url):
        score -= 40
    if looks_like_navigation(title, content):
        score -= 60
    if looks_like_listing_page(title, content):
        score -= 90
    if looks_like_report_or_rule(title, content):
        score -= 50
    if looks_like_regulation_page(title, content):
        score -= 90
    if title_is_non_event(title):
        score -= 70
    if not has_event_signal(title, content):
        score -= 40
    if is_low_signal(text):
        score -= 30
    if is_irrelevant_agent_topic(topic, title, content):
        score -= 120
    return score


def build_impact_label(title: str, content: str) -> str:
    event_type = classify_event_type(title, content)
    if event_type == "realized_incident":
        return "公开材料描述了已经发生的损害或失控行为，具体范围以原文为准"
    if event_type == "observed_attack":
        return "已观察到真实恶意活动，但公开材料未必披露具体受害组织和损失"
    if event_type == "measured_exposure":
        return "属于资产暴露或生态测量结果，不等同于已发生业务事故"
    if event_type == "warning_or_guidance":
        return "属于风险预警或治理建议，不能表述为已发生事故"
    return "公开材料未充分披露实际影响，需进一步复核"


def event_type_label(event_type: str) -> str:
    return {
        "realized_incident": "已发生损害的真实事件",
        "observed_attack": "已观察到的真实攻击活动",
        "measured_exposure": "暴露面或生态实测",
        "warning_or_guidance": "风险预警或治理指南",
        "unclassified": "待复核事件",
    }.get(event_type, "待复核事件")


def should_drop_result(title: str, content: str, url: str, date_text: str) -> bool:
    bucket = source_bucket(url)
    if bucket == "blocked":
        return True
    if not is_recent_enough(date_text, title, url):
        return True
    if looks_like_navigation(title, content):
        return True
    if looks_like_listing_page(title, content):
        return True
    if looks_like_report_or_rule(title, content):
        return True
    if looks_like_regulation_page(title, content):
        return True
    if title_is_non_event(title):
        return True
    if not has_event_signal(title, content):
        return True
    return False


def collect_events(
    payload: dict[str, Any],
    topic: str,
    industry: str,
    risk_tags: list[str],
    customer_name: str = "",
) -> list[dict[str, Any]]:
    candidates: list[dict[str, Any]] = []
    seen: set[str] = set()
    for query_item in payload.get("queries", []):
        query_id = str(query_item.get("id", "")).strip()
        query = str(query_item.get("query", "")).strip()
        for result in query_item.get("results", []) or []:
            title = str(result.get("title", "")).strip()
            url = str(result.get("url", "")).strip()
            content = str(result.get("content", "")).strip()
            date_text = str(result.get("published_date", "") or "").strip()
            if not title or not url:
                continue
            if should_drop_result(title, content, url, date_text):
                continue
            if is_irrelevant_agent_topic(topic, title, content):
                continue
            topic_seed = primary_topic_seed(topic).lower()
            direct_topic_match = bool(topic_seed and topic_seed in f"{title} {content} {url}".lower())
            analogue_query = query_id in {
                "customer_direct_incident_zh",
                "customer_direct_incident_en",
                "industry_recent",
                "industry_analogue_en",
            }
            if topic_seed and not direct_topic_match and not analogue_query:
                continue
            if query_id.startswith("customer_direct_") and customer_name.lower() not in f"{title} {content}".lower():
                continue
            key = url or normalize_title(title)
            if key in seen:
                continue
            seen.add(key)
            candidates.append(
                {
                    "title": title,
                    "date": date_text,
                    "summary": content,
                    "event_type": classify_event_type(title, content),
                    "impact": build_impact_label(title, content),
                    "relevance_reason": build_relevance_reason(primary_topic_seed(topic), industry, risk_tags, " ".join([title, content])),
                    "source": url,
                    "query": query,
                    "query_id": query_id,
                    "direct_topic_match": direct_topic_match,
                    "score": score_event(topic, industry, risk_tags, title, content, query, url, date_text),
                    "source_bucket": source_bucket(url),
                }
            )
    candidates.sort(key=lambda item: (-int(item["score"]), item["source_bucket"], item["title"]))
    return candidates


def select_events(events: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    priority: list[dict[str, Any]] = []
    used_sources: set[str] = set()
    used_incidents: set[str] = set()

    def incident_key(event: dict[str, Any]) -> str:
        text = f"{event.get('title', '')} {event.get('summary', '')}".lower()
        if "meta" in text and any(term in text for term in ("email", "inbox", "邮件", "邮箱")):
            return "meta-openclaw-email-deletion"
        if any(term in text for term in ("malicious skill", "恶意skill", "恶意 skill", "技能投毒")):
            return "malicious-skills"
        if any(term in text for term in ("fake installer", "假冒安装", "虚假安装")):
            return "fake-installer"
        normalized = normalize_title(re.sub(r"[-|｜].*$", "", text))
        return normalized[:80] or str(event.get("source", ""))

    def take(pool: list[dict[str, Any]], limit: int = 3) -> None:
        for event in pool:
            if len(priority) >= limit:
                break
            key = incident_key(event)
            if event["source"] in used_sources or key in used_incidents:
                continue
            priority.append(event)
            used_sources.add(event["source"])
            used_incidents.add(key)

    def title_has_action_signal(event: dict[str, Any]) -> bool:
        title = str(event.get("title", "")).lower()
        return any(term in title for term in REALIZED_IMPACT_TERMS + OBSERVED_ATTACK_TERMS)

    direct_title_actual = [
        event
        for event in events
        if str(event.get("query_id", "")).startswith("topic_")
        and event["event_type"] in ("realized_incident", "observed_attack")
        and title_has_action_signal(event)
    ]
    direct_context_actual = [
        event
        for event in events
        if str(event.get("query_id", "")).startswith("topic_")
        and event["event_type"] in ("realized_incident", "observed_attack")
        and not title_has_action_signal(event)
    ]
    direct_measured = [
        event
        for event in events
        if str(event.get("query_id", "")).startswith("topic_") and event["event_type"] == "measured_exposure"
    ]
    analogue_actual = [
        event
        for event in events
        if event["event_type"] in ("realized_incident", "observed_attack")
        and event not in direct_title_actual
        and event not in direct_context_actual
    ]
    warnings = [event for event in events if event["event_type"] == "warning_or_guidance"]

    take(direct_title_actual)
    take(direct_measured)
    if len(priority) < 3:
        take(warnings[:1])
    take(direct_context_actual)
    take(analogue_actual)

    supplemental: list[dict[str, Any]] = []
    for event in events:
        key = incident_key(event)
        if event["source"] in used_sources or key in used_incidents:
            continue
        supplemental.append(event)
        used_incidents.add(key)
        if len(supplemental) >= 3:
            break
    return priority, supplemental


def render_markdown(
    customer_name: str,
    industry: str,
    topic: str,
    scenario: str,
    priority_events: list[dict[str, Any]],
    supplemental_events: list[dict[str, Any]],
    talking_points: list[str],
) -> str:
    lines = [
        f"# {customer_name} 相关安全事件摘要",
        "",
        f"- 生成时间: {datetime.now().isoformat(timespec='seconds')}",
        f"- 客户行业: {industry or '未提供'}",
        f"- 主题: {topic or '未提供'}",
        f"- 场景: {scenario or '未提供'}",
        "",
        "## 一、优先推荐的真实事件",
        "",
    ]
    if priority_events:
        for index, event in enumerate(priority_events, start=1):
            lines.extend(
                [
                    f"### 事件{index}: {event['title']}",
                    f"- 时间: {event['date'] or '公开材料未明确披露'}",
                    f"- 核心内容: {event['summary'] or '公开材料未提供足够摘要'}",
                    f"- 影响范围: {event['impact']}",
                    f"- 为什么和这个客户有关: {event['relevance_reason']}",
                    f"- 来源: {event['source']}",
                    "",
                ]
            )
    else:
        lines.extend(["- 当前未筛到高价值事件。", ""])

    lines.extend(["## 二、补充热点事件", ""])
    if supplemental_events:
        for index, event in enumerate(supplemental_events, start=1):
            lines.extend(
                [
                    f"### 补充事件{index}: {event['title']}",
                    f"- 时间: {event['date'] or '公开材料未明确披露'}",
                    f"- 核心内容: {event['summary'] or '公开材料未提供足够摘要'}",
                    f"- 为什么和这个客户有关: {event['relevance_reason']}",
                    f"- 来源: {event['source']}",
                    "",
                ]
            )
    else:
        lines.extend(["- 当前无补充热点事件。", ""])

    lines.extend(["## 三、交流切入点", ""])
    for index, point in enumerate(talking_points, start=1):
        lines.append(f"{index}. {point}")
    lines.append("")
    return "\n".join(lines)


def render_chat_summary(customer_name: str, priority_events: list[dict[str, Any]], talking_points: list[str], markdown_path: Path) -> str:
    lines = [f"{customer_name} 安全事件速览", ""]
    for event in priority_events[:3]:
        lines.append(f"- {event['title']}：{event['relevance_reason']}")
    if not priority_events:
        lines.append("- 当前未筛到高价值事件，建议复核搜索词。")
    lines.append("")
    lines.append("交流话术切口")
    for point in talking_points[:2]:
        lines.append(f"- {point}")
    lines.append("")
    lines.append(f"产物路径：{markdown_path}")
    return "\n".join(lines)


def summarize_impact(event: dict[str, Any]) -> str:
    impact = str(event.get("impact", "")).strip()
    if impact and "需结合原文" not in impact:
        return impact
    summary = str(event.get("summary", "")).strip()
    if summary:
        return summary
    return "涉及对外服务、账号体系或业务数据，需结合原文进一步确认影响范围。"


def summarize_disposition(event: dict[str, Any]) -> str:
    text = " ".join(
        [
            str(event.get("title", "")).strip(),
            str(event.get("summary", "")).strip(),
            str(event.get("source", "")).strip(),
        ]
    )
    lowered = text.lower()
    if any(term in lowered for term in ("restored", "recovered", "恢复", "找回")):
        return "公开材料提到数据或业务已恢复，仍需以原文披露的范围为准。"
    if any(term in lowered for term in ("修复", "patched", "fixed", "封禁", "下线")):
        return "公开材料明确提到修复、封禁或下线动作；不额外推断是否完成全面整改。"
    if event.get("event_type") == "warning_or_guidance":
        return "这是预警或治理建议，不应写成已经完成整改或处罚的事故。"
    return "公开材料未充分披露后续恢复和整改结果，交流时不扩写处置结论。"


def build_exchange_point(event: dict[str, Any], customer_name: str) -> str:
    text = " ".join(
        [
            str(event.get("title", "")).strip(),
            str(event.get("summary", "")).strip(),
            str(event.get("relevance_reason", "")).strip(),
        ]
    )
    lowered = text.lower()
    if any(term in lowered for term in ("openclaw", "智能体", "agent", "deleted", "删除", "失控", "ignored commands")):
        return f"这类事件适合让 {customer_name} 讨论智能体的最小权限、批量操作审批、实时中止、回滚恢复和完整审计。"
    if any(term in text for term in ("诈骗", "补贴", "短信", "通知", "钓鱼")):
        return f"这类事件对 {customer_name} 最适合切入通知链路可信校验、短信/邮件防仿冒和群众侧反诈联动。"
    if any(term in text for term in ("未授权", "越权", "接口", "查询", "目录")):
        return "这类事件可以直接映射到查询接口鉴权、最小权限控制和批量探测防护。"
    if any(term in text for term in ("泄露", "窃取", "共享", "FTP", "导出")):
        return "这类事件适合落到数据外发、共享目录、外包协作和日志审计闭环。"
    relevance = str(event.get("relevance_reason", "")).strip()
    if relevance:
        return f"这条事件适合交流，不是因为新闻热度，而是因为它能直接映射到 {relevance}。"
    return "这条事件更适合作为交流切口，而不是泛化新闻，因为它能落到具体业务后果和整改动作。"


def build_search_axis(topic: str, industry: str, scenario: str) -> str:
    parts = [part for part in (topic, industry, scenario) if part]
    return " + ".join(parts) if parts else "客户场景 + 数据安全"


def build_dimension_judgement(topic: str, industry: str, scenario: str, risk_tags: list[str]) -> str:
    dimensions: list[str] = []
    if topic:
        dimensions.append(f"主题维度 = {topic}")
    if industry:
        dimensions.append(f"行业维度 = {industry}")
    if scenario:
        dimensions.append(f"场景维度 = {scenario}")
    if risk_tags:
        dimensions.append(f"风险维度 = {' / '.join(risk_tags[:4])}")
    return "；".join(dimensions) if dimensions else "按客户场景综合判断"


def render_structured_event(index: int, event: dict[str, Any], customer_name: str) -> list[str]:
    return [
        f"### 事件{index}：{event['title']}",
        f"- **时间**：{event['date'] or '公开材料未明确披露'}",
        f"- **事实类型**：{event_type_label(str(event.get('event_type', 'unclassified')))}",
        f"- **核心内容**：{event['summary'] or '公开材料未提供足够摘要'}",
        f"- **影响范围**：{summarize_impact(event)}",
        f"- **处理结果**：{summarize_disposition(event)}",
        f"- **可用于交流的点**：{build_exchange_point(event, customer_name)}",
        f"- **来源**：{event['source']}",
        "",
    ]


def render_detailed_markdown(
    customer_name: str,
    industry: str,
    topic: str,
    scenario: str,
    risk_tags: list[str],
    priority_events: list[dict[str, Any]],
    supplemental_events: list[dict[str, Any]],
    talking_points: list[str],
) -> str:
    now = datetime.now()
    cover_from = now.replace(year=now.year - 1).strftime("%Y-%m-%d")
    cover_to = now.strftime("%Y-%m-%d")

    stitched_points = list(talking_points[:4])
    default_points = [
        "先盘点智能体能访问的数据、工具、账号和网络，再决定是否允许进入正式业务环境。",
        "删除、发送、转账、发布、修改配置等不可逆动作必须设置人工确认、速率限制和紧急中止。",
        "第三方 Skills 应按软件供应链管理，经过代码审查、权限审查、签名校验和隔离测试后再准入。",
        "交流时先讲已经发生的业务损害，再映射权限、隔离、审计和恢复能力，最后补充监管要求。",
    ]
    while len(stitched_points) < 4:
        stitched_points.append(default_points[len(stitched_points)])

    lines = [
        f"# {customer_name}_数据安全交流_{now.strftime('%Y%m%d_%H%M%S')}",
        f"> 生成时间：{now.strftime('%Y-%m-%d %H:%M:%S')}",
        f"> 客户行业：{industry or '未提供'}",
        f"> 覆盖时段：{cover_from} ~ {cover_to}",
        f"> 搜索主轴：{build_search_axis(topic, industry, scenario)}",
        f"> 维度判断：{build_dimension_judgement(topic, industry, scenario, risk_tags)}",
        "> 筛选偏好：全球真实损害事件优先，其次是已观察到的攻击活动和暴露面实测，机构预警仅作补充",
        (
            f"说明：这一版优先挑选对 {customer_name} 最有代入感的真实案例，并明确区分已发生损害、"
            "真实攻击活动、暴露面实测和风险预警，避免把潜在风险写成已经发生的事故。"
        ),
        "",
        "## 一、优先推荐的事件",
        "",
    ]
    if priority_events:
        for index, event in enumerate(priority_events, start=1):
            lines.extend(render_structured_event(index, event, customer_name))
    else:
        lines.extend(["- 当前未筛到高价值优先事件，建议复核搜索主轴或扩大时间范围。", ""])

    lines.extend(["## 二、补充热点事件", ""])
    if supplemental_events:
        for index, event in enumerate(supplemental_events, start=1):
            lines.extend(render_structured_event(index, event, customer_name))
    else:
        lines.extend(["- 当前无补充热点事件。", ""])

    lines.extend([f"## 三、给{customer_name}最容易接住的4个切口", ""])
    for index, point in enumerate(stitched_points, start=1):
        lines.append(f"{index}. {point}")

    lines.extend(
        [
            "",
            "## 四、这次交流可直接复用的话术",
            "",
            f"- `对 {customer_name} 来说，智能体最大的变化不是会回答问题，而是能拿着真实账号直接执行操作；防护重点必须从内容安全扩展到权限、行为和业务后果。`",
            "- `近期案例已经出现智能体无视停止命令、批量删除数据，以及恶意 Skills 投递窃密软件，说明高危动作不能只靠提示词约束。`",
            "- `建议先把智能体的资产、账号、Skills、可访问数据和外联地址盘清楚，再建立最小权限、人工审批、实时中止、回滚恢复和审计闭环。`",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> int:
    args = build_parser().parse_args()
    customer_name, industry = enrich_context(args)
    topic = args.topic.strip()
    scenario = args.scenario.strip() or "售前交流"
    risk_tags = split_csv(args.risk_tags) or ["账号被盗", "数据泄露", "业务中断", "通知仿冒"]

    queries = build_queries(customer_name, topic, industry, scenario, risk_tags)
    if args.search_payload:
        search_payload = load_json(args.search_payload)
    else:
        search_payload = collect_live_payload(queries, args.tavily_api_key, args.max_results)

    search_payload.setdefault("customer_name", customer_name)
    search_payload.setdefault("industry", industry)
    search_payload.setdefault("topic", topic)
    search_payload.setdefault("scenario", scenario)
    search_payload.setdefault("risk_tags", risk_tags)
    search_payload.setdefault("queries", [])

    if args.save_search_payload:
        target = Path(args.save_search_payload)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(json.dumps(search_payload, ensure_ascii=False, indent=2), encoding="utf-8")

    events = collect_events(search_payload, topic, industry, risk_tags, customer_name)
    priority_events, supplemental_events = select_events(events)
    status = "success" if priority_events else "partial"

    talking_points = [
        "优先从已发生的数据删除、凭据泄露、业务中断或失控操作切入，再回到权限与治理能力。",
        "智能体的高危动作不能只依赖自然语言指令约束，应配置强制审批、速率限制、实时中止和可回滚机制。",
        "第三方 Skills、安装包、外部网页和消息都应视为不可信输入，纳入供应链审查和运行时监测。",
        "把风险预警放在真实事件之后，用于补充监管要求和安全基线，而不是替代事故案例。",
    ]
    if topic:
        talking_points.insert(0, f"围绕 {topic} 的真实事件更适合做交流切口，因为它能直接映射到当前主题风险。")

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    base_name = safe_name(customer_name)
    markdown_path = output_dir / f"{base_name}_安全事件_{timestamp}.md"
    detailed_markdown_path = output_dir / f"{base_name}_安全事件详细解读_{timestamp}.md"
    summary_path = output_dir / f"{base_name}_安全事件摘要_{timestamp}.txt"
    json_path = output_dir / f"{base_name}_安全事件_{timestamp}.json"

    markdown_path.write_text(
        render_markdown(customer_name, industry, topic, scenario, priority_events, supplemental_events, talking_points),
        encoding="utf-8",
    )
    detailed_markdown_path.write_text(
        render_detailed_markdown(
            customer_name,
            industry,
            topic,
            scenario,
            risk_tags,
            priority_events,
            supplemental_events,
            talking_points,
        ),
        encoding="utf-8",
    )
    summary_path.write_text(
        render_chat_summary(customer_name, priority_events, talking_points, markdown_path),
        encoding="utf-8",
    )
    json_path.write_text(
        json.dumps(
            {
                "status": status,
                "customer_name": customer_name,
                "industry": industry,
                "topic": topic,
                "scenario": scenario,
                "risk_tags": risk_tags,
                "search_queries": [item["query"] for item in queries],
                "priority_events": priority_events,
                "supplemental_events": supplemental_events,
                "talking_points": talking_points,
                "markdown_path": str(markdown_path),
                "detailed_markdown_path": str(detailed_markdown_path),
                "summary_path": str(summary_path),
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    print(f"Markdown: {markdown_path}")
    print(f"Detailed Markdown: {detailed_markdown_path}")
    print(f"Summary: {summary_path}")
    print(f"JSON: {json_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
